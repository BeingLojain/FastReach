<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>FastReach</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
    /* -----------------------------------------[Header]------------------------------------------------ */
        html {
            scroll-behavior: smooth;
        }
        body{
            margin: 0;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            background: hsla(0, 0%, 100%, 0.495);
            box-shadow: 2px 2px 10px #555;
            position: fixed;
            width: calc(100% - 80px);
            top: 0;
            left: 0;
            transition: background 0.3s ease;
            z-index: 1000;
            font-family: "Times New Roman", Arial, sans-serif;
        }

        .hamburger {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }

        .navbar.scrolled {
            background: white; 
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            height: 40px;
            margin-right: 10px;
        }
        .logo a {
            text-decoration: none;
            color: #6B5A69;
            font-size: 27px;
            font-weight: bold;
        }
        .logo a:hover {
            color: #2d3c47;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            position: relative;
        }
        .nav-links a {
            text-decoration: none;
            color: #555;
            font-weight: bold;
            padding: 10px;
            display: block;
        }
        .nav-links a:hover, .nav-links .active {
            color: black;
            border-bottom: 3px solid #6B5A69;
        }

        .nav-links.show {
            display: block;
        }


        @media (max-width: 768px) {
            .nav-links {
                display: none;
                flex-direction: column;
                background: white;
                position: absolute;
                top: 60px;
                right: 0;
                width: 250px;
                box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
                padding: 10px;
                font-family: "Times New Roman", Arial, sans-serif;
            }
            
            .nav-links.show {
                display: flex;
            }

            .hamburger {
                display: block;
            }

            .services-dropdown .dropdown {
                display: none;
                flex-direction: column;
                background: white;
                padding: 10px;
                box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
                position: relative;
                top: 0;
                left: 0;
                list-style-type: none;
            }

            .services-dropdown .dropdown.show {
                display: flex;
            }
        }

        .dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: hsl(0, 0%, 100%);
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 150px;
            list-style: none;
            padding: 0;

        }
        .dropdown a {
            padding: 10px;
            white-space: nowrap;
            display: block;
        }
        .nav-links li:hover .dropdown {
            display: block;
        }
        .login-btn {
            background: #6B5A69;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 20px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }
        .login-btn:hover {
            background: #243b4a;
        }

        .user-icon {
        width: 30px;
        height: 30px;
        background-image: url('../images/userP.png');
        background-size: cover;
        transition: background-image 0.3s ease;
        }

        .user-icon:hover {
        background-image: url('../images/userB.png');
        }

        .user-login-container {
            display: flex;
            align-items: center;
            gap: 10px; 
        }

        #cart {
            width: 35px;
        }

        #cart:hover {
            content: url('../images/purchase-books-blue.png'); 
        }


        .about-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100vh;
            background: rgba(24, 36, 45, 0.95);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.5s ease, visibility 0.5s ease;
            z-index: 9999;
        }
        .about-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        .about-content {
            max-width: 800px;
            padding: 20px;
        }
        .about-content h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            color: #cbd5dd;
        }
        .about-content p {
            font-size: 1.2rem;
            line-height: 1.6;
            color: #cbd5dd;
        }
        .close-btn {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 2rem;
            cursor: pointer;
            color: #cbd5dd;
        }
        .close-btn:hover {
            color: #6B5A69;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 5px 15px;
            background: rgba(107, 90, 105, 0.1);
            border-radius: 20px;
            transition: all 0.3s ease;
        }

        .user-info:hover {
            background: rgba(107, 90, 105, 0.2);
        }

        .user-name {
            color: #6B5A69;
            font-weight: 500;
            font-size: 0.95rem;
            font-family: "Times New Roman", Arial, sans-serif;
        }

    </style>
</head>

<body>
    <!-------------------------------------- Header --------------------------------------------->
    <header>

    <nav class="navbar" id="navbar">
        <div class="logo">
            <img src="../images/uni-logo.png" alt="College Logo">
            <a href="home.php">FastReach</a>
        </div>

        <ul class="nav-links" id="nav-links">
            <li><a href="../home/home.php" class="active">Home</a></li>

            <!-- About Section (Always visible) -->
            <li><a href="#" id="about-trigger">About</a></li>
            <div class="about-overlay" id="about-overlay">
                <span class="close-btn" id="close-about">&times;</span>
                <div class="about-content">
                    <h1>About FastReach</h1>
                    <p>FastReach is your ultimate college platform, connecting students with services, news, and a vibrant community. From securing lockers to joining clubs, FastReach enhances your college experience effortlessly.</p>
                </div>
            </div>

            <!-- Services (Only if logged in) -->
            <?php if (isset($_SESSION['student_id'])): ?>
            <li class="services-dropdown">
                <a href="#" id="services-toggle">Services ▼</a>
                <ul class="dropdown" id="services-menu">
                    <li><a href="..\locker\LockersHome.php">Lockers</a></li>
                    <li><a href="..\Books\BooksMainPage.php">Books</a></li>
                    <li><a href="..\clubs\clubs.php">Clubs</a></li>
                </ul>
            </li>
            <?php endif; ?>

            <!-- Contact (Always visible) -->
            <li><a href="../home/home.php#news">News</a></li>

            <li><a href="#contact">Contact</a></li>
        </ul>

        <!-- Profile/Login Section -->
        <div class="user-login-container">
            <?php if (isset($_SESSION['student_id'])): ?>
                <a href="../cart/cart.php"><img src="../images/purchase-books-purple.png" alt="cart" id="cart"></a>
                <a href="../home/userProfile.php"><div class="user-icon"></div></a> 
                <div class="user-info">
                    <span class="user-name">Welcome, <?php echo explode(" ", $_SESSION['student_name'])[0]; ?></span>
                </div>               
                <a href="../home/logout.php" class="login-btn">Logout</a>
            <?php else: ?>
                <a href="../home/login.php" class="login-btn">Login</a>
            <?php endif; ?>
        </div>

        <div class="hamburger" id="hamburger">
            <i class="fas fa-bars"></i>
        </div>
    </nav>
    </header>
    <script>
    window.addEventListener("scroll", function() {
        let navbar = document.getElementById("navbar");
        if (window.scrollY > 50) {
            navbar.classList.add("scrolled");
        } else {
            navbar.classList.remove("scrolled");
        }
    });
    </script>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const aboutLinks = document.querySelectorAll("#about-link, #about-link-footer");
        const aboutOverlay = document.querySelector(".about-overlay");
        const closeBtn = document.querySelector(".close-btn");

        aboutLinks.forEach(link => {
            link.addEventListener("click", function(event) {
                event.preventDefault();
                aboutOverlay.classList.add("active");
            });
        });

        closeBtn.addEventListener("click", function() {
            aboutOverlay.classList.remove("active");
        });
    });
    </script>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const hamburger = document.getElementById("hamburger");
        const navLinks = document.getElementById("nav-links");
        const servicesToggle = document.getElementById("services-toggle");
        const servicesMenu = document.getElementById("services-menu");

        hamburger.addEventListener("click", function() {
            navLinks.classList.toggle("show");
        });

        servicesToggle.addEventListener("click", function(e) {
            e.preventDefault();
            servicesMenu.classList.toggle("show");
        });
    });
    </script>
    <script>
    document.getElementById("about-trigger").addEventListener("click", function(event) {
        event.preventDefault();
        document.getElementById("about-overlay").classList.add("active");
        document.body.style.overflow = "hidden";
    });
    document.getElementById("close-about").addEventListener("click", function() {
        document.getElementById("about-overlay").classList.remove("active");
        document.body.style.overflow = "";
    });
    </script>

</body>

</html>