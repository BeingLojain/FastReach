<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pickup Information in FastReach</title>
  <style>
    body {
      font-family: "Times New Roman", Arial, sans-serif;
      background: #f4f4f4;
      color: #333;
      padding: 40px;
    }
    .container {
      max-width: 800px;
      margin: auto;
      background: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.1);
    }
    h1 {
      color: #6B5A69;;;
      text-align: center;
      margin-bottom: 20px;
    }
    p {
      font-size: 16px;
      line-height: 1.6;
    }
    #map {
      height: 350px;
      width: 100%;
      border-radius: 12px;
      margin-top: 25px;
    }
    .back-button {
      display: inline-block;
      margin-top: 25px;
      background-color: #6b5861;
      color: white;
      padding: 10px 18px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }
    .back-button:hover {
      background-color: #8a6b75;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1> Book Pickup Location</h1>
    <p>
      If you had purchased a book through FastReach, you can pick it up at the shown location below, please bring your student ID and the confirmation of your order.
    </p>
    <p><strong>Location:</strong> College of Science and Humanities – Jubail</p>
    <p><strong>Pickup Hours:</strong> Sunday to Thursday, 8:00 AM – 3:00 PM</p>

    <div id="map"></div>

    <a href="javascript:history.back()" class="back-button">← Back</a>
  </div>

  <script>
    function initMap() {
      const collegeLocation = { lat: 27.128556, lng: 49.552417 };
      const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 18,
        center: collegeLocation,
      });
      new google.maps.Marker({
        position: collegeLocation,
        map,
        title: "College of Science and Humanities, Jubail"
      });
    }
  </script>
  <script async defer 
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5CkywJVeYyXYqNwMEK2wfCvFccLHccs8&callback=initMap">
  </script>
</body>
</html>
