<?php
session_start();

include('../include/db_connect.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];  // Student_ID or Admin_Username
    $password = $_POST['password'];  // S_Password or A_Password

    $sql_admin = "SELECT * FROM admin WHERE A_Username = '$username' AND A_Password = '$password'";
    $result_admin = $conn->query($sql_admin);

    if ($result_admin->num_rows > 0) {
        $admin = $result_admin->fetch_assoc();
        $_SESSION['admin_username'] = $admin['A_Username'];  
        $_SESSION['admin_name'] = $admin['A_Fname'] . " " . $admin['A_Lname']; // Admin's full name
        $_SESSION['user_type'] = 'admin';  
        $_SESSION['Admin_ID'] = $admin['Admin_ID'];
        
        header('Location: ../Admin/admin_dashboard.php');
        exit();
    }

    $sql_student = "SELECT * FROM student WHERE Student_ID = '$username' AND S_Password = '$password'";
    $result_student = $conn->query($sql_student);

    if ($result_student->num_rows > 0) {
        $student = $result_student->fetch_assoc();
        $_SESSION['student_id'] = $student['Student_ID']; 
        $_SESSION['student_name'] = $student['S_Fname'] . " " . $student['S_Lname'];  // Student's full name
        $_SESSION['user_type'] = 'student';
        $_SESSION['just_logged_in'] = true;

        if (isset($_SESSION['redirect_after_login'])) {
            $redirect = $_SESSION['redirect_after_login'];
            unset($_SESSION['redirect_after_login']);
            header("Location: $redirect");
        } else {
            header('Location: home.php');
        }
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IAU Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(to right, #243b4a, #788fa1);
            margin: 0;
        }

        .login-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 100%;
            max-width: 350px;
        }

        .logo {
            width: 80px;
            margin-bottom: 1rem;
        }

        h2 {
            color: #243b4a;
            margin-bottom: 1rem;
        }

        .input-group {
            margin-bottom: 1rem;
            text-align: left;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .login-btn {
            width: 100%;
            padding: 0.75rem;
            background: #243b4a;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .login-btn:hover {
            background: #1b2d3a;
        }

        .forgot-password {
            display: block;
            margin-top: 1rem;
            color: #243b4a;
            text-decoration: none;
            font-size: 0.9rem;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        .login-container p {
            margin: 12px 0;
        }

        footer {
            background-color: #18242d;
            color: white;
            padding: 35px 20px;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <img src="../images/uni-logo.png" alt="IAU Logo" class="logo">
            <h2>Welcome to IAU</h2>

            <!-- Display error message if login fails -->
            <?php if (isset($error_message)) { ?>
                <div style="color: red; margin-bottom: 1rem;">
                    <?php echo $error_message; ?>
                </div>
            <?php } ?>

            <!-- Login form -->
            <form method="POST" action="">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your Student ID or Admin Username" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>

                <!-- Submit button -->
                <button type="submit" class="login-btn">Login</button>
                
                <a href="ResetPassword.html" class="forgot-password">Forgot your password?</a>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 FastReach | All Rights Reserved</p>
    </footer>
</body>
</html>
