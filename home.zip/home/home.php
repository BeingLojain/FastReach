<?php
session_start();

include('../include/db_connect.php'); 
include '../include/header.php'; // Header of the page

$newsData = [];
$sql = "SELECT News_ID, News_Title, News_image_url, news_link FROM news"; 
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $newsData[] = [
            'id' => $row['News_ID'],
            'image' => $row['News_image_url'],
            'title' => $row['News_Title'],
            'link' => $row['news_link']
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FastReach</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <!-- Cookie handling functions -->
    <script>
        // Function to get cookie value by name
        function getCookie(name) {
            try {
                const cookies = document.cookie.split(';');
                for (let cookie of cookies) {
                    const [cookieName, cookieValue] = cookie.split('=').map(c => c.trim());
                    if (cookieName === name) {
                        return decodeURIComponent(cookieValue); // First decode
                    }
                }
                return null;
            } catch (error) {
                console.error('Error getting cookie:', error);
                return null;
            }
        }

        // Function to get the appropriate link based on item type
        function getItemLink(itemType) {
            switch(itemType) {
                case 'book':
                    return '../Books/BooksMainPage.php';
                case 'note':
                    return '../Books/BooksMainPage.php';
                default:
                    return '../home/home.php';
            }
        }

        // Function to get item type display text
        function getItemTypeText(itemType) {
            switch(itemType) {
                case 'book':
                    return 'Book';
                case 'note':
                    return 'Note';
                default:
                    return 'Item';
            }
        }

        // Function to check and display last purchase notification
        function checkLastPurchase() {
            const cookieConsent = getCookie('cookieConsent');
            if (cookieConsent !== 'accepted') {
                return; // Don't show last purchase if cookies were rejected
            }

            // Check if user just logged in (PHP will set this variable)
            const justLoggedIn = <?php echo isset($_SESSION['just_logged_in']) ? 'true' : 'false'; ?>;
            
            // If user didn't just log in, don't show the popup
            if (!justLoggedIn) {
                return;
            }

            try {
                const lastPurchaseCookie = getCookie('lastPurchase');
                if (lastPurchaseCookie) {
                    // Decode the cookie value again as it's double encoded
                    const decodedValue = decodeURIComponent(lastPurchaseCookie);
                    const purchaseData = JSON.parse(decodedValue);

                    const notification = document.getElementById('lastPurchaseNotification');
                    const itemSpan = document.getElementById('lastPurchaseItem');
                    const buyAgainBtn = document.getElementById('buyAgainBtn');
                    const notificationTitle = document.querySelector('#lastPurchaseNotification h3');

                    if (notification && itemSpan && buyAgainBtn && notificationTitle) {
                        const itemType = getItemTypeText(purchaseData.itemType);
                        notificationTitle.textContent = `Previous ${itemType} Purchase`;
                        itemSpan.textContent = purchaseData.itemName;
                        buyAgainBtn.href = getItemLink(purchaseData.itemType);
                        notification.style.display = 'block';
                    }
                }
            } catch (error) {
                console.error('Error checking last purchase:', error);
            }
        }

        // Close notification
        function closeNotification() {
            const notification = document.getElementById('lastPurchaseNotification');
            if (notification) {
                notification.style.display = 'none';
            }
        }

        // Run check when page loads
        document.addEventListener('DOMContentLoaded', function() {
            checkLastPurchase();
        });
    </script>

    <style>        

        body{
            margin: 0;
            padding: 0;
        }
        /*section 1---------------------------------------------------------------------------*/

        .section1{
            background: linear-gradient( hsla(0, 0%, 0%, 0.655),  hsla(0, 0%, 0%, 0.649)), url(../images/collageJubail.png);
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: left;
            background-size: cover;
            background-position: center;
            padding: 20px;
            border-bottom: solid 3px #243b4a;

        }

        .section1 h1{
            color: #cbd5dd;
            font-size: 60px;
        }

        .section1 p{
            color:#cbd5dd;
            font-size: 30px;
        }

        /*------news ----------------------------------------------------*/

        .news-carousel {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .news-div {
            background-color: #cbd5dd;
            display: flex;
            flex-direction: column; 
            justify-content: center;
            align-items: center;
            height: auto; 
            padding: 30px 20px;
            margin-bottom: 50px;
        }

        .news-heading {
            font-size: 36px;
            font-weight: bold;
            color: #18242d;
            text-align: center;
            margin-bottom: 10px; 
        }

        .news-container {
            position: relative;
            background: white;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            width: 20%;
            max-width: 800px;
            margin-bottom: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            z-index: 10;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .news-container:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .news-image {
            width: 100%;
            border-radius: 10px;
            height: auto;
            object-fit: cover;
        }

        .date {
            color: #2d3c47;
            font-size: 16px;
            display: block;
            margin-top: 10px;
        }

        .news-title {
            font-size: 28px;
            color: black;
            margin: 10px 0;
        }

        .read-more {
            display: inline-block;
            margin-top: 10px;
            color: #2d3c47;
            text-decoration: none;
            font-weight: bold;
        }

        .nav-button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: none;
            padding: 12px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 22px;
        }

        .left {
            left: 3px;
        }

        .right {
            right: 3px;
        }


        @media (max-width: 768px) {
            .news-heading {
                font-size: 28px;
                margin-bottom: 20px;
            }

            .news-container {
                width: 90%;
                padding: 30px;
            }

            .news-title {
                font-size: 24px;
            }

            .news-text {
                font-size: 16px;
            }
        }


        /* Services Section ---------------------------------------------------------------------*/
        .services-section {
            padding: 50px 20px;
            background: #f4f4f4;
            text-align: center;
        }

        .services-heading {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 40px;
        }

        .services-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .service-card {
            background: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .service-card:hover {
            transform: translateY(-10px); 
        }

        .service-icon {
            max-width: 60px;
            height: auto;
            margin-bottom: 15px;
        }

        .service-card h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .service-card p {
            font-size: 16px;
            color: #777;
        }

        .service-btn {
            background-color: #6B5A69;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 15px;
        }
        .service-btn:hover {
            background-color: #2d3c47;
        }

        /* Last Purchase Notification Styles ------------------------------------------*/
        .notification-popup {
            display: none;
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 8px;
            padding: 15px 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-width: 350px;
            border-left: 4px solid #243b4a;
        }

        .notification-popup .close-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            cursor: pointer;
            color: #666;
            font-size: 18px;
        }

        .notification-popup h3 {
            margin: 0 0 10px 0;
            color: #243b4a;
            font-size: 16px;
        }

        .notification-popup p {
            margin: 0 0 15px 0;
            color: #666;
            font-size: 14px;
        }

        .notification-popup .action-buttons {
            display: flex;
            gap: 10px;
        }

        .notification-popup .buy-again {
            padding: 8px 15px;
            background-color: #243b4a;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            transition: background-color 0.2s;
        }

        .notification-popup .buy-again:hover {
            background-color: #1a2d3a;
        }

        .notification-popup .dismiss {
            padding: 8px 15px;
            background-color: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .notification-popup .dismiss:hover {
            background-color: #d0d0d0;
        }

        /* Cookie Consent Popup Styles------------------------------------------------ */
        .cookie-consent {
            display: none;
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-width: 400px;
            text-align: center;
            border-left: 4px solid #243b4a;
        }

        .cookie-consent h3 {
            margin: 0 0 10px 0;
            color: #243b4a;
            font-size: 18px;
        }

        .cookie-consent p {
            margin: 0 0 15px 0;
            color: #666;
            font-size: 14px;
            line-height: 1.5;
        }

        .cookie-buttons {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .cookie-accept, .cookie-reject {
            padding: 8px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            border: none;
            transition: background-color 0.2s;
        }

        .cookie-accept {
            background-color: #243b4a;
            color: white;
        }

        .cookie-accept:hover {
            background-color: #1a2d3a;
        }

        .cookie-reject {
            background-color: #e0e0e0;
            color: #333;
        }

        .cookie-reject:hover {
            background-color: #d0d0d0;
        }

    </style>
</head>

<body>
    <!-- Cookie Consent Popup -->
    <div id="cookieConsent" class="cookie-consent">
        <h3>Cookie Consent</h3>
        <p>We use cookies to enhance your experience and track your last purchases. Would you like to enable cookies?</p>
        <div class="cookie-buttons">
            <button class="cookie-accept" onclick="handleCookieConsent(true)">Accept</button>
            <button class="cookie-reject" onclick="handleCookieConsent(false)">Reject</button>
        </div>
    </div>
    <!-- --------------------[ Chatboot & Back to top Buttons] -------------------------------->
    <?php include '../include/shared_buttons.html' ;?>

        <!-- Last Purchase Notification -->
    <div id="lastPurchaseNotification" class="notification-popup">
        <span class="close-btn" onclick="closeNotification()">&times;</span>
        <h3>Previous Purchase</h3>
        <p>Would you like to buy <span id="lastPurchaseItem"></span> again?</p>
        <div class="action-buttons">
            <a id="buyAgainBtn" href="#" class="buy-again">Buy Again</a>
            <button class="dismiss" onclick="closeNotification()">Not Now</button>
        </div>
    </div>


        <!-- -------------------------------------------------------Section start------------------------------------------------ -->
    <section class="section1" id="home">
        <h1>Welcome to FastReach</h1>
        <p>Your go-to platform for all things related to college services, news, and more. Stay updated with the latest announcements, explore services, and connect with the community.</p>
    </section>

    <section class="services-section" id="service">
        <h2 class="services-heading">Explore Our Services</h2>
        <div class="services-container">
            <!-- Lockers -->
            <div class="service-card">
                <img src="../images/locker.png" alt="Lockers" class="service-icon">
                <h3>Lockers</h3>
                <p>Secure your personal items in our student lockers. Easy booking and access!</p>
                <?php if (isset($_SESSION['student_id'])): ?>
                    <a href="../locker/LockersHome.php" class="service-btn">Explore Lockers</a>
                <?php endif; ?>
            </div>
    
            <!-- Books -->
            <div class="service-card">
                <img src="../images/book.png" alt="Books" class="service-icon">
                <h3>Books</h3>
                <p>Browse our library catalog and check out books you need for your courses!</p>
                <?php if (isset($_SESSION['student_id'])): ?>
                    <a href="../Books/BooksMainPage.php" class="service-btn">Explore Books</a>
                <?php endif; ?>
            </div>
    
            <!-- Clubs -->
            <div class="service-card">
                <img src="../images/group.png" alt="Clubs" class="service-icon">
                <h3>Clubs</h3>
                <p>Join a club, meet new people, and enhance your college experience.</p>
                <?php if (isset($_SESSION['student_id'])): ?>
                    <a href="../clubs/clubs.php" class="service-btn">Explore Clubs</a>
                <?php endif; ?>
            </div>
    
    </section>
    
        <!-- ----------------------------------------------------news start------------------------------------------------ -->

    
    
<div class="news-div" id="news">
    <div class="news-heading">
        <h2>University News</h2>
    </div>
    <div class="news-container">
        <?php
        if (!empty($newsData)) {
            foreach ($newsData as $newsItem) {
                echo '<div class="news">';
                echo '<img src="' . $newsItem['image'] . '" class="news-image" alt="' . $newsItem['title'] . '">';
                echo '<h2 class="news-title">' . $newsItem['title'] . '</h2>';
                echo '<a href="' . $newsItem['link'] . '" class="read-more" target="_blank" onclick="fetch(\'track_view.php?news_id=' . $newsItem['id'] . '\')">Join Us</a>';
                echo '</div>';
            }
        } else {
            echo '<p>No news available at the moment.</p>';
        }
        ?>
        <button class="nav-button left"><i class="fas fa-arrow-left"></i></button>
        <button class="nav-button right"><i class="fas fa-arrow-right"></i></button>
    </div>
</div>  

<!-----------------------------------------------------news script---------------------------------------------------->

<script>
    let currentIndex = 0;

    const newsItems = document.querySelectorAll('.news');  // Get all news items dynamically added
    const totalNews = newsItems.length;

    function updateNews(index) {
        newsItems.forEach((news, i) => {
            news.style.display = i === index ? 'block' : 'none'; // Show only the current news item
        });
    }

    document.querySelector(".left").addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + totalNews) % totalNews;
        updateNews(currentIndex);
    });

    document.querySelector(".right").addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % totalNews;
        updateNews(currentIndex);
    });

    // Initialize the first news item
    updateNews(currentIndex);
</script>

  <!-- --------------------[footer] ---------------------------->
  <?php include '../include/footer.html' ;
    unset($_SESSION['just_logged_in']);
    ?>

  <script>
    // Cookie consent handling functions
    function setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    function handleCookieConsent(accepted) {
        // Save the user's preference
        setCookie('cookieConsent', accepted ? 'accepted' : 'rejected', 365);
        
        // Hide the popup
        document.getElementById('cookieConsent').style.display = 'none';
        
        // If rejected, clear any existing cookies
        if (!accepted) {
            // Clear the last purchase cookie if it exists
            document.cookie = 'lastPurchase=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
        }
    }

    // Check if we should show the cookie consent popup
    document.addEventListener('DOMContentLoaded', function() {
        const cookieConsent = getCookie('cookieConsent');
        if (cookieConsent === null) {
            // Only show if user hasn't made a choice yet
            document.getElementById('cookieConsent').style.display = 'block';
        }
        
        // Only check last purchase if cookies were accepted
        if (cookieConsent === 'accepted') {
            checkLastPurchase();
        }
    });
</script>

</body>

</html>
