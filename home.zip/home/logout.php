<?php
session_start();

session_unset();

session_destroy();

unset($_SESSION['student_id']);
unset($_SESSION['student_name']);
unset($_SESSION['admin_username']);
unset($_SESSION['user_type']);

header('Location: ../home/home.php');


exit();

echo '<script type="text/javascript">
        window.location.reload();
      </script>';
exit();

?>
