<?php
session_start();
include('../include/db_connect.php');

if (isset($_SESSION['student_id']) && isset($_GET['news_id'])) {
    $student_id = $_SESSION['student_id'];
    $news_id = intval($_GET['news_id']);

    // تأكد أن العرض لم يُسجل مسبقاً
    $check = $conn->prepare("SELECT * FROM Student_View_News WHERE Student_ID = ? AND News_ID = ?");
    $check->bind_param("ii", $student_id, $news_id);
    $check->execute();
    $check_result = $check->get_result();

    if ($check_result->num_rows == 0) {
        $insert = $conn->prepare("INSERT INTO Student_View_News (Student_ID, News_ID) VALUES (?, ?)");
        $insert->bind_param("ii", $student_id, $news_id);
        $insert->execute();
    }
}
?>
