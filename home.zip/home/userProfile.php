<?php
include('../include/db_connect.php');
session_start();


if (isset($_SESSION['student_id'])) {
  $student_id = $_SESSION['student_id'];

  // Fetch student details
  $sql = $conn->prepare("SELECT * FROM Student WHERE Student_ID = ?");
  $sql->bind_param("i", $student_id);
  $sql->execute();
  $result = $sql->get_result();

  if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
  } else {
    echo "No records found.";
    exit;
  }

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION['student_id'])) {
      $student_id = $_SESSION['student_id'];
      
      if (isset($_POST['book_id'])) {
        $book_id = $_POST['book_id'];
        $stmt = $conn->prepare("DELETE FROM favoritesbook WHERE Student_ID = ? AND Book_ID = ?");
        $stmt->bind_param("ii", $student_id, $book_id);
        $stmt->execute();
        $stmt->close();
        header("Location: userprofile.php");
        exit();
        
      } elseif (isset($_POST['note_id'])) {
        $note_id = $_POST['note_id'];
        $stmt = $conn->prepare("DELETE FROM favoritesnote WHERE Student_ID = ? AND Note_ID = ?");
        $stmt->bind_param("ii", $student_id, $note_id);
        $stmt->execute();
        $stmt->close();
        header("Location: userprofile.php");
        exit();
      }
    }
  }  

  function getItems($conn, $query, $id) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result();
  }

  // Book and Note Sections
  $books_bought = getItems($conn, "SELECT * FROM book WHERE bought_by = ?", $student_id);
  $books_sold = getItems($conn, "SELECT * FROM book WHERE added_by = ? AND bought_by IS NOT NULL", $student_id);
  $books_forsale = getItems($conn, "SELECT * FROM book WHERE added_by = ? AND bought_by IS NULL", $student_id);
  $books_favorites = getItems($conn, "SELECT B.* FROM book B JOIN favoritesbook F ON B.Book_ID = F.Book_ID WHERE F.Student_ID = ?", $student_id);

  $notes_bought = getItems($conn, "SELECT N.* FROM note N JOIN student_buy_note SBN ON N.Note_ID = SBN.Note_ID WHERE SBN.Student_ID = ?", $student_id);
  $notes_sold = getItems($conn, "SELECT * FROM note WHERE added_by = ? AND Note_ID IN (SELECT Note_ID FROM student_buy_note)", $student_id);
  $notes_forsale = getItems($conn, "SELECT * FROM note WHERE added_by = ? AND Note_ID NOT IN (SELECT Note_ID FROM student_buy_note)", $student_id);
  $notes_favorites = getItems($conn, "SELECT N.* FROM note N JOIN favoritesnote F ON N.Note_ID = F.Note_ID WHERE F.Student_ID = ?", $student_id);

  // Locker, Club
  $locker_result = $conn->query("SELECT * FROM locker WHERE std_id = $student_id LIMIT 1");
  $locker = $locker_result ? $locker_result->fetch_assoc() : null;

  $clubs = $conn->query("SELECT C.Club_Name FROM club C JOIN student_enrolls_clubs S ON C.Club_ID = S.Club_ID WHERE S.Student_ID = $student_id");

  function renderItems($items, $type = 'book', $showBuyer = false, $isFavorite = false) {
    global $conn;
    ob_start();
    while ($item = $items->fetch_assoc()) {
      echo "<div class='book-details'>";
  
      // LEFT SIDE: Image
      $imageField = $type === 'book' ? 'Book_image_URL' : 'Note_image_URL';
      $imageURL = $item[$imageField];

      if (!empty($imageURL)) {
        $imagePath = "../Books/" . htmlspecialchars($imageURL);
        echo "<div><img src='$imagePath' alt='Image' width='120' style='border-radius: 10px;'></div>";
      } else {
        echo "<div><img src='placeholder.png' alt='No Image' width='120' style='opacity:0.3; border-radius: 10px;'></div>";
      }
  
      // RIGHT SIDE: Details
      echo "<div>";
      echo "<h3>" . htmlspecialchars($item[$type == 'book' ? 'Book_Title' : 'Note_Title']) . " (ID: " . $item[$type == 'book' ? 'Book_ID' : 'Note_ID'] . ")</h3>";
      echo "<p><strong>Description:</strong> " . htmlspecialchars($item[$type == 'book' ? 'Book_description' : 'Note_description']) . "</p>";
      echo "<p><strong>Price:</strong> " . ($type == 'book' ? $item['B_price'] : $item['N_price']) . " SAR</p>";
      echo "<p><strong>Major:</strong> " . htmlspecialchars($item[$type == 'book' ? 'Book_major' : 'Note_major']) . "</p>";
  
      // Show Buyer Info (for sold items)
      if ($showBuyer && !empty($item['bought_by'])) {
        $buyer_id = $item['bought_by'];
        $buyer = $conn->query("SELECT * FROM student WHERE Student_ID = $buyer_id")->fetch_assoc();
        if ($buyer) {
          echo "<p><strong>Buyer Information:</strong> " . htmlspecialchars($buyer['S_Fname'] . ' ' . $buyer['S_Lname']) . " (ID: " . $buyer['Student_ID'] . ")</p>";
          echo "<p><strong>Email:</strong> " . $buyer['S_Email'] . " | <strong>Phone:</strong> " . $buyer['S_PhoneNumber'] . "</p>";
        }
      }
  
      // Show Added by Info (for bought items)
      if (!$showBuyer && !empty($item['added_by'])) {
        $adder_id = $item['added_by'];
        $adder = $conn->query("SELECT * FROM student WHERE Student_ID = $adder_id")->fetch_assoc();
        if ($adder) {
          echo "<p><strong>Seller Information:</strong> " . htmlspecialchars($adder['S_Fname'] . ' ' . $adder['S_Lname']) . " (ID: " . $adder['Student_ID'] . ")</p>";
          echo "<p><strong>Email:</strong> " . $adder['S_Email'] . " | <strong>Phone:</strong> " . $adder['S_PhoneNumber'] . "</p>";
        }
      }
  
      // Favorite Button (only in favorites section)
      if ($isFavorite) {
        echo "<form method='post' action=''>";
        echo "<input type='hidden' name='{$type}_id' value='" . $item[$type == 'book' ? 'Book_ID' : 'Note_ID'] . "' />";
        echo "<button type='submit' class='unfav-btn'>Remove from Favorites</button>";
        echo "</form>";
      }
  
      echo "</div>"; // End right side
      echo "</div>"; // End book-details
    }
    return ob_get_clean();
  }
  

  $details = [
    'bought_books' => renderItems($books_bought, 'book'),
    'bought_notes' => renderItems($notes_bought, 'note'),
    'favorite_books' => renderItems($books_favorites, 'book', false, true),
    'favorite_notes' => renderItems($notes_favorites, 'note', false, true),
    'sold_books' => renderItems($books_sold, 'book', true),
    'sold_notes' => renderItems($notes_sold, 'note', true),
    'forsale_books' => renderItems($books_forsale, 'book'),
    'forsale_notes' => renderItems($notes_forsale, 'note'),
  ];
} else {
  header('Location: login.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Times New Roman", sans-serif;
    }

    body {
      background: linear-gradient(to bottom right, #6B5A69, #ffffff);
      color: #333;
      height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .profile-container {
      flex: 1;
      margin: 20px;
      background: rgba(255, 255, 255, 0.95);
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      overflow-y: auto;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 40px;
    }

    .header h1 {
      font-size: 32px;
      color: #6B5A69;
    }

    .back-button {
      font-size: 16px;
      text-decoration: none;
      color: #6B5A69;
      background-color: #6b5a6924;
      padding: 10px 16px;
      border-radius: 10px;
      transition: 0.3s;
    }

    .back-button:hover {
      background-color: #6b5a6970;
    }

    h2 {
      font-size: 24px;
      margin-bottom: 20px;
      color: #6B5A69;
    }

    h {
      font-size: 24px;
      margin-bottom: 20px;
      color: #6B5A69;
    }

    .details-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 25px;
      margin-bottom: 40px;
    }

    .details-grid div {
      background: #6b5a6911;
      border-radius: 12px;
      padding: 20px;
      box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.03);
    }

    h5 {
      font-size: 14px;
      color: #666;
      margin-bottom: 5px;
    }

    p {
      font-size: 16px;
      font-weight: 500;
    }

    .book-details {
      display: flex;
      gap: 20px;
      background: #f8f8f8;
      padding: 20px;
      margin-bottom: 10px;
      border-left: 5px solid #6B5A69;
      border-radius: 12px;
      align-items: flex-start;
    }


    .section-title {
      cursor: pointer;
      color: #6B5A69;
      font-weight: 600;
      font-weight: bold;
      text-decoration: none; 
    }

    .section-title p {
      font-weight: bold; 
    }

    .section-title:hover {
      color: #2d3c47;
    }

    .section-content {
      margin-top: 10px;
    }
    .section-title {
      cursor: pointer;
      color: #6B5A69;
      font-weight: bold;
      text-decoration: underline;
    }
    .book-details {
      background: #f8f8f8;
      padding: 20px;
      margin-bottom: 10px;
      border-left: 5px solid #6B5A69;
    }
    .detail-section {
      margin-top: 50px;
    }
    .unfav-btn {
      margin-top: 10px;
      padding: 6px 12px;
      background-color: #6B5A69;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }
    .unfav-btn:hover {
      background-color: #4b3f4d;
    }
  </style>

  <script>
    function showDetail(id) {
      const sections = document.querySelectorAll(".detail-section > div");
      sections.forEach(section => section.style.display = "none");
      const target = document.getElementById(id);
      if (target) {
        target.style.display = "block";
        window.scrollTo({
          top: target.offsetTop - 50,
          behavior: 'smooth'
        });
      }
    }
  </script>
</head>

<body>

<div class="profile-container">
<div class="header">
    <a href="javascript:history.back()" class="back-button">&#8592; Back</a>
    <h1>Student Profile</h1>
  </div>

  <h2>Personal Information</h2>
    <div class="details-grid">
      <div>
        <h5>Name</h5>
        <p><?php echo $student['S_Fname'] . " " . $student['S_Lname']; ?></p>
      </div>
      <div>
        <h5>Student ID</h5>
        <p><?php echo $student['Student_ID']; ?></p>
      </div>
      <div>
        <h5>Email</h5>
        <p><?php echo $student['S_Email']; ?></p>
      </div>
      <div>
        <h5>Phone</h5>
        <p><?php echo $student['S_PhoneNumber']; ?></p>
      </div>
      <div>
        <h5>Gender</h5>
        <p><?php echo $student['S_Gender']; ?></p>
      </div>
      <div>
        <h5>Password</h5>
        <p>********</p>
      </div>
      <div>
        <h5>Bank Account</h5>
        <p><?php echo $student['S_BankAccount']; ?></p>
      </div>
      <div>
        <h5>Address</h5>
        <p><?php echo $student['Street_Name'] . ", " . $student['City'] . ", " . $student['Postal_Code']; ?></p>
      </div>
      <div>
        <h5>College</h5>
        <p><?php echo $student['S_Collage']; ?></p>
      </div>
      <div>
        <h5>Major</h5>
        <p><?php echo $student['S_Major']; ?></p>
      </div>
    </div>

  <h2>Activity Summary</h2>
  <div class="details-grid">
    <div>
      <h5>Booked Locker</h5>
      <?php if ($locker): ?>
        <form action="../locker/RentLockerDetails.php" method="POST" style="display:inline;">
          <input type="hidden" name="locker_number" value="<?= htmlspecialchars($locker['locker_number']) ?>">
          <button type="submit" class="section-title" style="background:none; border:none; cursor:pointer; font-size:inherit; padding:0;">
            <?= "Locker " . htmlspecialchars($locker['locker_number']) . " - Block " . htmlspecialchars($locker['locker_block']) ?>
          </button>
        </form>

      <?php else: ?>
        <p>No locker booked</p>
      <?php endif; ?>
    </div>
    <div>
      <h5>Clubs Enrolled In</h5>
      <p>
        <?php
        if ($clubs->num_rows > 0) {
          $names = [];
          while ($c = $clubs->fetch_assoc()) $names[] = $c['Club_Name'];
          echo count($names) . " (" . implode(", ", $names) . ")";
        } else echo "None";
        ?>
      </p>
    </div>
    <?php
      $count_labels = [
        'bought_books' => 'Bought Books',
        'bought_notes' => 'Bought Notes',
        'favorite_books' => 'Favorite Books',
        'favorite_notes' => 'Favorite Notes',
      ];
      foreach ($count_labels as $key => $label) {
        echo "<div><h5>$label</h5><p class='section-title' onclick=\"showDetail('$key')\">" . substr_count($details[$key], 'book-details') . " items</p></div>";
      }
    ?>
    
  </div>

  <h2>Books and Notes Selling Activities</h2>
    <div class="details-grid">
      <?php
        $count_labels = [
          'sold_books' => 'Sold Books',
          'sold_notes' => 'Sold Notes',
          'forsale_books' => 'Books for Sale',
          'forsale_notes' => 'Notes for Sale',
        ];
        foreach ($count_labels as $key => $label) {
          echo "<div><h5>$label</h5><p class='section-title' onclick=\"showDetail('$key')\">" . substr_count($details[$key], 'book-details') . " items</p></div>";
        }
      ?>
    </div>
    <?php

    $section_titles = [
      'bought_books' => 'Bought Books',
      'bought_notes' => 'Bought Notes',
      'favorite_books' => 'Favorite Books',
      'favorite_notes' => 'Favorite Notes',
      'sold_books' => 'Sold Books',
      'sold_notes' => 'Sold Notes',
      'forsale_books' => 'Books for Sale',
      'forsale_notes' => 'Notes for Sale',
    ];
    ?>

  <div class="detail-section">
    <?php foreach ($details as $id => $html): ?>
      <div id="<?= $id ?>" style="display:none">
        <h2><?= $section_titles[$id] ?? ucwords(str_replace('_', ' ', $id)) ?></h2>
        <?= $html ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>

</body>
</html>
