<!-- --------------------[Header] ---------------------------->
<?php 
session_start();

$studentID = $_SESSION['student_id'];


include '../include/header.php'; // Header of the page
include '../include/db_connect.php'; // db connection file

//check if the student already has a locker
$studentHasLocker= false;
$lockerCheckStmt= $conn->prepare("SELECT 1 FROM Locker WHERE std_id = ?");
$lockerCheckStmt->bind_param("s", $studentID);
$lockerCheckStmt->execute();
$lockerCheckStmt->store_result();

if ($lockerCheckStmt->num_rows > 0){
    $studentHasLocker = true; // std found to has a locker
}
$lockerCheckStmt->close();
?>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Rent Locker</title>
    <link rel="stylesheet" href="LockersHomeStyles.css" />
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

    <!-- --------------------[ Chatboot & Back to top Buttons] -------------------------------->
    <?php include '../include/shared_buttons.html' ;?>

    <!-- --------------------[Home Page] -------------------------------->
    <section class="home">
        <div class="Locker-Home">
            <h1>Rent Locker</h1>
            <p>
                Our Student Locker Rental Service offers students a streamlined and secure solution for renting personal
                storage spaces on campus, ensuring convenience and peace of mind.
            </p>
            <!--This button will go to the select locker page-->
            <a href="#available-lockers-section">
                <button type="button" id="button-1">Get your locker</button>
            </a>
        </div>
    </section>

    <!-- --------------------[Process Page] -------------------------------->
    <section class="process-section">


        <h2>  Get Your Locker </h2>

        <div class="Process-container">
            <!--Card 1-->
            <div class="card" id="card-1">
                <img id="icon-1" src="../images/locationIcon.png" alt="Location Icon" />
                <h3>Select The Section</h3>
                <p>Choose from our multiple college sections and buildings</p>
            </div>

            <!--Card 2-->
            <div class="card" id="card-2">
                <img id="icon-2" src="../images/LockIcon.png" alt="Lock Icon" />
                <h3>Pick Your Locker</h3>
                <p>Browse available lockers and select your preferred one</p>
            </div>

            <!--Card 3-->
            <div class="card" id="card-3">
                <img id="icon-3" src="../images/PaymentIcon.png" alt="Payment Icon" />
                <h3>Complete Payment</h3>
                <p>Secure your locker with our easy payment process</p>
            </div>
        </div>


    </section>




    <!-- -------------------------------------------[Choose Locker Page]-------------------------------------------------- -->
    <section class="available-lockers-section" id="available-lockers-section">
        <div class="available-lockers-container" id="parent">
            <div id="div-x">
                <div class="filter-bar" id="div-1">
                    <!-- list to filter the lockers by sections-->
                    <div class="filter">
                        <select name="location" id="location">
                            <option value="">Select Location</option>

                            <?php // this php is for the options in the drop list
                                include '../include/db_connect.php';

                                $student_id = $_SESSION['student_id'];
                                
                                // to get the college of the std
                                $query = "select S_Collage from Student where Student_ID = ?";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("i", $student_id);
                                $stmt->execute();
                                $stmt->bind_result($student_college);
                                $stmt->fetch();
                                $stmt->close();
                                
                                // to get the sections in the college of the std
                                // so only the sections in the std coolage are shown
                                $query = "SELECT DISTINCT locker_section FROM Locker WHERE locker_college = ?";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("s", $student_college);
                                $stmt->execute();
                                $result = $stmt->get_result();
                
                                // add the sections to list
                                while ($row = $result->fetch_assoc()) {
                                    echo '<option value="' . htmlspecialchars($row['locker_section']) . '">' . htmlspecialchars($row['locker_section']) . '</option>';
                                }
                                $stmt->close();
                                $conn->close();
                            ?>
                            <!-- end php tag -->
                        </select>


                    </div>
                </div>

                <!-- //TODO: the img not done yet -->
                <div class="locker-image" id="div-2">
                    <!-- img is displayd from css file -->
                </div>

                <div class="available-lockers-container-2" id="div-3">
                    <h2>Available Lockers</h2>

                    <!-- Read the blocks that r assosiated w the chosen section (locker_section & locker_block) -->
                    <div class="choose-block-container" id="div-4">
                        <h5>Choose Block</h5>

                        <div class="blocks-buttons-container">
                            <!-- the buttons now works from javascripts and locker_blocks.php -->
                        </div>
                    </div>

                    <div class="choose-locker-container" id="div-5">
                        <h5>Choose Locker</h5>
                        <div class="lockers-buttons-container">
                            <!-- the buttons now works from javascripts and locker_numbers.php -->
                        </div>
                    </div>

                    <!-- if student has locker it will not be able to continue -->
                    <?php if (!$studentHasLocker): ?>
                    <button id="select-locker-btn" type="button">Select</button>
                    <?php else: ?>
                    <button type="button" id="select-locker-btn-unavailable" class="unavailable"
                        onclick="select_alert()">Select</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>





    <!-- -------------------------- [Display Locker Blocks and Locker Number Buttons] ---------------------------- -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const locationSelect = document.getElementById('location');
        const blockContainer = document.querySelector('.blocks-buttons-container');
        const lockerContainer = document.querySelector('.lockers-buttons-container');
        const selectBtn = document.getElementById('select-locker-btn');

        let selectedBlock = null;
        let selectedLocker = null;

        function updateLockerButtons(section, block) { // shows locker buttons based on selected section & block
            fetch(
                    `locker_numbers.php?section=${encodeURIComponent(section)}&block=${encodeURIComponent(block)}`
                )
                .then(response => response
            .json()) // convert the response from lockers_number.php from php into js array
                .then(data => {
                    lockerContainer.innerHTML = ""; // if there's a current buttons then clear them

                    if (data.length === 0) {
                        lockerContainer.innerHTML =
                            "<p style='color: #243b4a;'>No lockers was found in this block.</p>";
                        return;
                    }

                    data.forEach(locker => {

                        // create btns for each locker
                        const btn = document.createElement("button");
                        btn.className = "locker-buttons";
                        btn.textContent = locker.number;
                        btn.type = "button";

                        // rented lockers 
                        if (locker.status === "Rented") {
                            btn.classList.add(
                            "rented-button"); // add the rented btns to this class to get a different stylings
                            btn.disabled = true;
                            btn.addEventListener("click", () => {
                                alert(
                                    "This locker is already rented. Please choose another one.");
                            });
                        }

                        // availble lockers
                        else {
                            btn.addEventListener("click", () => {
                                document.querySelectorAll('.locker-buttons').forEach(b => b
                                    .classList.remove('selected-button')
                                    ); // remove the selected styles from the prev selected btn when a new one is clickied
                                btn.classList.add(
                                'selected-button'); // add the selected btns to this class to get a different stylings
                                selectedLocker = locker.number;
                            });
                        }
                        lockerContainer.appendChild(btn); // add btn to the container (in html)
                    });
                })
                .catch(error => {
                    console.error("Error fetching lockers:", error);
                });
        }

        function getBlocks(section = null) { // gets the locker blocks

            // if the std has selected a section then include it in url request, else just call the file
            let url = section ? `locker_blocks.php?section=${encodeURIComponent(section)}` :
                `locker_blocks.php`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    blockContainer.innerHTML = ""; // if there's a current buttons then clear them

                    if (data.error) {
                        console.error(data.error);
                        return;
                    }

                    if (!section && data.section) {
                        locationSelect.value = data
                        .section; // make the returned section as auto selected in the list
                    }

                    // create btns for each block
                    data.blocks.forEach((block, index) => {
                        const btn = document.createElement("button");
                        btn.className = "block-button";
                        btn.textContent = block;

                        // block button clicked
                        btn.addEventListener("click", () => {
                            document.querySelectorAll(".block-button").forEach(b => b
                                .classList.remove("selected-button")
                                ); // remove the selected styles from the prev selected btn when a new one is clickied
                            btn.classList.add("selected-button");
                            selectedBlock = block;
                            selectedLocker = null;
                            updateLockerButtons(locationSelect.value,
                            block); // gets the lockers for the selected block
                        });
                        blockContainer.appendChild(btn);

                        // by defualt will select 1st block button to disply the locker num btns
                        if (index === 0) {
                            btn.classList.add("selected-button");
                            selectedBlock = block;
                            updateLockerButtons(locationSelect.value, block);
                        }
                    });
                })
                .catch(error => console.error("Error fetching blocks:", error));
        }

        getBlocks();

        locationSelect.addEventListener('change',
            function() { // when a new section is selected then gets its blocks
                if (this.value !== '') {
                    getBlocks(this.value);
                }
            });

        // select locker button clicked
        if (selectBtn) {
            selectBtn.addEventListener("click", function() {
                if (!selectedBlock || !selectedLocker) {
                    alert("Please select both a block and a locker before continuing.");
                    return;
                }

                //create form and submit it
                const form = document.createElement("form");
                form.method = "POST";
                form.action = "RentLockerDetails.php";

                // send the locker_number to details page
                const input = document.createElement("input");
                input.type = "hidden";
                input.name = "locker_number";
                input.value = selectedLocker;

                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            });
        }
    });
    </script>

    <script>
    function select_alert() {
        alert("You already renting a locker.");
        window.location.href = "LockersHome.php#available-lockers-section";
    }
    </script>


    <!-- --------------------[footer] ---------------------------->
    <?php include '../include/footer.html' ;?>
</body>

</html>