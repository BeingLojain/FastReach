<?php
session_start();

// redirect std to login if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}
include '../include/db_connect.php';

$student_id = $_SESSION['student_id'];

// student collage
$sql= "select S_Collage from Student where Student_ID = ?";
$stmt= $conn->prepare($sql);
$stmt->bind_param("i", $student_id) ;
$stmt->execute();
$result = $stmt->get_result();
$student= $result->fetch_assoc();
$college= $student['S_Collage'] ;

// get the selected section from the home
$section = isset($_GET['section']) ? $_GET['section'] : null;

if ($section){// if the std has selected a section then disply its blocks
    $sql= "SELECT DISTINCT locker_block FROM Locker WHERE locker_section = ? AND locker_college = ?";
    $stmt= $conn->prepare($sql);
    $stmt->bind_param("ss", $section, $college);
} 

else{// if no section is selected , then by defualt display the blocks of the 1st section

    $sql= "SELECT DISTINCT locker_section FROM Locker WHERE locker_college = ? ORDER BY locker_section ASC LIMIT 1";
    $stmt= $conn->prepare($sql);
    $stmt->bind_param("s", $college);
    $stmt->execute();
    $result = $stmt->get_result();
    $first_section = $result->fetch_assoc();

    if (!$first_section){
        alert('No sections is found in your college') ;
        exit;
    }

    $section = $first_section['locker_section'];

    //get the blocks for this 1st section in college
    $sql= "SELECT DISTINCT locker_block FROM Locker WHERE locker_section = ? AND locker_college = ?";
    $stmt= $conn->prepare($sql);
    $stmt->bind_param("ss", $section, $college);
}

$stmt->execute();
$result = $stmt->get_result();
$blocks = [];

while ($row = $result->fetch_assoc()) {
    $blocks[] = $row['locker_block'];
}

echo json_encode(["section" => $section, "blocks" => $blocks]);

$conn->close();
?>
