<?php
session_start();

// redirect std to login if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}
include '../include/db_connect.php';

$studentID = $_SESSION['student_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['locker_number'])) {
    $locker_number = $_POST['locker_number'];

    $stmt = $conn->prepare("SELECT locker_rentPrice FROM Locker WHERE locker_number = ?");
    $stmt->bind_param("i", $locker_number);
    $stmt->execute();
    $stmt->bind_result($price);
    $stmt->fetch();
    $stmt->close();
} else {
    echo "<p style='color:red;'>No locker selected for payment.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <style>
    /* General Styles */

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }

    html {
        scroll-behavior: smooth;
    }

    body {
        height: 100%;
        width: 100%;
        background: linear-gradient(to bottom, rgba(163, 143, 128, 0.9), rgba(199, 184, 176, 0.9)),
            url("../images/lockersBG.png");
        background-size: cover;
        background-position: center;
        margin: 0;
        padding-top: 20px;
        align-content: center;
    }

    /* Container */
    .container {
        max-width: 700px;
        /* margin: 120px auto 20px; */
        margin: auto;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 15px;
        backdrop-filter: blur(10px);
        box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;
        background: #f8f8f8;
    }

    .header {
        text-align: center;
        padding: 18px;
        border-radius: 10px;
        color: #fff;
        background: linear-gradient(to right, #243b4a, #788fa1);
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 18px;
    }

    /* Payment Section */
    .box {
        padding: 18px;
        border-radius: 10px;
        border-left: 6px solid #806375;
        background: rgba(255, 255, 255, 0.7);
        box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;
        margin-bottom: 18px;
    }

    /* Buttons */
    .btn {
        width: 100%;
        padding: 12px;
        border-radius: 30px;
        font-size: 18px;
        font-weight: bold;
        text-align: center;
        color: #ffffff;
        background: linear-gradient(90deg, #243b4a 10%, #788fa1 100%);
        box-shadow: inset 0.4px 1px 4px rgba(36, 59, 74, 0.8);
        transition: all 0.1s ease-in-out;
        display: block;
        margin-top: 20px;
        cursor: pointer;
    }

    .btn:hover {
        text-shadow: 0px 0px 10px #c7b8b0;
        box-shadow: inset 0.4px 1px 4px rgba(36, 59, 74, 1),
            2px 4px 8px rgba(120, 143, 161, 0.5);
        transform: scale(1.02);
    }

    /* Footer */
    footer{
        background-color: #18242d;
        color: white;
        padding: 35px 20px;
        text-align: center;
        bottom: 0;
        width: 100%
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="container">
            <div class="header">Payment</div>

            <form method="POST" action="payment_process.php">
                <input type="hidden" name="locker_number" value="<?php echo $locker_number; ?>">

                <div class="box">
                    <h3>Choose Payment Method</h3>
                    <select name="payment_method" id="payment-method" class="w-full p-2 border rounded">
                        <option value="card">Credit/Debit Card</option>
                        <option value="cash">Cash</option>
                    </select>
                </div>

                <div id="card-details" class="box">
                    <h3>Card Details</h3>
                    <input type="text" class="w-full p-2 border rounded mb-2" placeholder="Card Number">
                    <input type="text" class="w-full p-2 border rounded mb-2" placeholder="Cardholder Name">
                    <input type="text" class="w-full p-2 border rounded mb-2" placeholder="CVC">
                    <input type="date" class="w-full p-2 border rounded mb-2">
                </div>

                <div class="box">
                    <h3>Price</h3>
                    <p><img src='../images/Saudi_Riyal_Symbol.svg.webp' alt='currency' class='inline-block w-4 h-4'>
                        <?php echo htmlspecialchars($price); ?></p>
                </div>

                <div class="box">
                    <h3>Terms and Conditions</h3>
                    <ul class="text-sm list-disc pl-5">
                        <li>The locker is for personal use only.</li>
                        <li>Ensure the locker remains locked when not in use.</li>
                        <li>Unauthorized key duplication is prohibited.</li>
                    </ul>
                    <label class="inline-flex items-center mt-2">
                        <input type="checkbox" id="agree" class="form-checkbox">
                        <span class="ml-2">I agree to the terms and conditions</span>
                    </label>
                </div>

                <button class="btn" id="complete-payment" disabled>Complete Order</button>
            </form>
        </div>

        <footer>
            <p>&copy; 2025 FastReach | All Rights Reserved</p>
        </footer>

        <script>
        document.getElementById("agree").addEventListener("change", function() {
            document.getElementById("complete-payment").disabled = !this.checked;
        });

        document.getElementById("payment-method").addEventListener("change", function() {
            let cardDetails = document.getElementById("card-details");
            if (this.value === "cash") {
                cardDetails.style.display = "none";
            } else {
                cardDetails.style.display = "block";
            }
        });
        </script>
</body>

</html>