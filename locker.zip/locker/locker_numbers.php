<?php
session_start();

// redirect std to login if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}
include '../include/db_connect.php';

$student_id = $_SESSION['student_id'];

// student collage
$studentQuery = $conn->prepare("SELECT S_Collage FROM Student WHERE Student_ID = ?");
$studentQuery->bind_param("i", $student_id);
$studentQuery->execute();
$studentResult = $studentQuery->get_result();
$college = $studentResult->fetch_assoc()['S_Collage'];

// the selected section & block in home
$section = $_GET['section'] ?? '';
$block = $_GET['block'] ?? '';

// get the number and status from db
$stmt = $conn->prepare("SELECT locker_number, locker_status FROM Locker WHERE locker_college = ? AND locker_section = ? AND locker_block = ?");
$stmt->bind_param("sss", $college, $section, $block);
$stmt->execute();
$result = $stmt->get_result();

$lockers = [];
while ($row = $result->fetch_assoc()) {
    $lockers[] = [
        'number' => $row['locker_number'],
        'status' => $row['locker_status']
    ];
}

echo json_encode($lockers);
?>



