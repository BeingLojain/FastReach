<?php
session_start();

// redirect std to login if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}
include '../include/db_connect.php';

$student_id = $_SESSION['student_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['locker_number'])) {
    $locker_number = $_POST['locker_number'];

    $rent_startDate = date("Y-m-d"); //the date the std has rented the locker

    // تاريخ نهاية السمستر نت الداتابيس
    $yearQuery= "select end_date from academic_year where is_current = 1";
    $yearResult = $conn->query($yearQuery) ;
    $rent_endDate = null;
    
    if ($row = $yearResult->fetch_assoc()) {
        $rent_endDate = $row['end_date'];
    } else {
        echo "<script>alert('Error: Academic year end date not found.');</script>";
        exit;
    }
    

    // update locker in DB to be rented
    $stmt = $conn->prepare("UPDATE Locker SET locker_status = 'Rented', std_id = ?, rent_startDate = ?, rent_endDate = ? WHERE locker_number = ?");
    $stmt->bind_param("sssi", $student_id, $rent_startDate, $rent_endDate, $locker_number);

    if ($stmt->execute()) {
        echo "<script>
            alert('Payment successful!\\nLocker #$locker_number has been reserved.');
            window.location.href = 'LockersHome.php';
        </script>";
    } else {
        echo "<script>
            alert('Error: Could not complete the transaction.');
            window.history.back();
        </script>";
    }
    
    $stmt->close();
    $conn->close();
    } else {
    echo "<script>
        alert('Invalid request. Locker number missing.');
        window.history.back();
    </script>";
    }
?>

