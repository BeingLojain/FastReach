<!-- --------------------[PHP - DB Connection] -------------------------------->
<!-- This php is to read std data from db -->
<?php
session_start();

// redirect std to login if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}
include '../include/db_connect.php';

$studentDetails = [
    "S_Fname" => "N/A",
    "S_Lname" => "",
    "Student_ID" => "N/A",
    "S_Collage" => "N/A",
    "S_PhoneNumbe" => "N/A",
    "S_Email" => "N/A"
];


$studentID = $_SESSION['student_id'];
$stmt = $conn->prepare("select * from student where Student_ID = ?");
$stmt->bind_param("s", $studentID) ; 
$stmt->execute();
$result= $stmt->get_result();

if ($result->num_rows > 0) {
    $studentDetails = $result->fetch_assoc();
} else {
    echo "No student found with ID: " . htmlspecialchars($studentID);
}

$today = date("Y-m-d");
$endDate = '';

//  end date from db
$yearQuery = "SELECT end_date from academic_year where is_current = 1 LIMIT 1";
$yearResult = $conn->query($yearQuery);
if ($row = $yearResult->fetch_assoc()) {
    $endDate = $row['end_date'];
}

?>

<?php // this php is to read the locker data from db based on the chosen locker number in LockersHome.php
include '../include/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['locker_number']) && !empty($_POST['locker_number'])) {
    $lockerNumber = $_POST['locker_number'];

    $query= "SELECT * from Locker where locker_number = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $lockerNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $locker = $result->fetch_assoc();
    } else {
        echo "<p style='color:red;'>Locker not found in the database.</p>";
        exit;
    }
} 
else {
    echo "<p style='color:red;'>No locker selected.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locker Details</title>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }

    html {
        scroll-behavior: smooth;
    }

    body {
        height: 100%;
        width: 100%;
        background: linear-gradient(to bottom,
                rgba(163, 143, 128, 0.9), rgba(199, 184, 176, 0.9)),
            url("../images/lockersBG.png");
        background-size: cover;
        background-position: center;
        margin: 0;
        padding-top: 20px;
        align-content: center;
    }

    .locker-details-container {
        max-width: 900px;
        margin: auto;
        padding: 20px;
        margin-bottom: 20px;
        border: solid 1px rgba(0, 0, 0, 0.1);
        border-radius: 15px;
        backdrop-filter: blur(10px);
        box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;
        background: #f8f8f8;
    }

    /* Header -- will be changed */
    .container-header {
        padding: 15px 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        color: #fff;
        background: linear-gradient(to right, #243b4a, #788fa1);
    }

    /* miight change style */
    .back-button {
        position: absolute;
        left: 20px;
        padding: 10px 15px;
        text-decoration: none;
        color: #fff;
        font-size: 16px;
        transition: 0.3s ease-in-out;
    }

    .back-button:hover {
        color: #e8c7c7;
    }

    h2 {
        padding: 15px 0 10px 0;
        color: #243b4a;
        font-size: 20px;
        border-bottom: 2px solid #806375;
    }

    .details-container {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-top: 10px;
    }

    .price,
    .email,
    .college {
        padding: 15px;
        margin: 2px 0 7px 0;
        grid-column: span 2;
        border-radius: 10px;
        border-left: 5px solid #806375;
        background: rgba(255, 255, 255, 0.6);
    }


    .college {
        margin-top: 15px;
    }

    .email {
        margin: 0;
    }

    .selected-locker {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
    }

    .selected-locker div,
    .price,
    .email,
    .college,
    .details-container div {
        padding: 15px;
        border-radius: 10px;
        border-left: 5px solid #806375;
        background: rgba(255, 255, 255, 0.6);
        color: #243b4a;
        box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;
    }


    h5 {
        display: block;
        margin-bottom: 5px;
        color: #243b4a;
        font-size: 18px;
        font-weight: bold;
        font-family: Arial, sans-serif;
    }

    p {
        margin: 0;
        font-size: 14px;
    }

    .price img {
        /* padding-top: 5px; */
        height: 12px;
        width: auto;
        vertical-align: middle;
    }

    .icon {
        width: auto;
        height: 20px;
        vertical-align: middle;
        padding-bottom: 4px;
    }

    #payment-btn {
        width: 250px;
        height: 50px;
        font-size: 18px;
        font-weight: bold;
        text-align: center;
        color: #ffffff;
        cursor: pointer;
        border: none;
        border-radius: 100px;
        background: linear-gradient(90deg, #243b4a 10%, #788fa1 100%);
        box-shadow: inset 0.4px 1px 4px rgba(36, 59, 74, 0.8);
        transition: all 0.1s ease-in-out;

        display: block;
        margin: 20px auto 10px auto;
        padding: 10px 20px;
    }

    #payment-btn:hover {
        text-shadow: 0px 0px 10px #c7b8b0;
        box-shadow: inset 0.4px 1px 4px rgba(36, 59, 74, 1),
            2px 4px 8px rgba(120, 143, 161, 0.5);
        transform: scale(1);
    }

    #payment-btn:active {
        background: linear-gradient(140deg, #243b4a 20%, #788fa1 100%);
        box-shadow: inset 0.4px 1px 8px rgba(120, 143, 161, 1),
            0px 0px 8px rgba(120, 143, 161, 0.6);
        text-shadow: 0px 0px 20px #788fa1;
        color: #dfe6eb;
        transform: scale(1);
    }

    a {
        text-decoration: none;
    }

    @media (max-width: 768px) {
        .details-container {
            grid-template-columns: 1fr;
        }

        .selected-locker {
            grid-template-columns: 1fr;
        }
    }
    </style>
</head>


<body>

    <!-- --------------------[Lockers Details Page] -------------------------------->
    <!-- This page display the details of the selected locker and the data of the student -->
    <div class="locker-details-container">

        <div class="container-header">
            <a href="LockersHome.php#available-lockers-section" class="back-button">&#8592; Back</a>
            <h1>Locker Details</h1>
        </div>

        <!-- --------------------[Locker Details] -------------------------------->
        <!-- locker data is from database based on the selected locker number in locker home -->
        <section class="locker-data-section">
            <h2> <img src="../images/LockIcon_Hover.png" alt="Lock Icon" class="icon"> Locker Details</h2>

            <div class="college">
                <h5>College</h5>
                <p>College of Science and Human Studies</p>
            </div>

            <div class="selected-locker">
                <div>
                    <h5>Section</h5>
                    <p><?php echo htmlspecialchars($locker['locker_section']); ?></p>
                </div>
                <div>
                    <h5>Block</h5>
                    <p><?php echo htmlspecialchars($locker['locker_block']); ?></p>
                </div>
                <div>
                    <h5>Locker Number</h5>
                    <p><?php echo htmlspecialchars($locker['locker_number']); ?></p>
                </div>
            </div>

            <div class="details-container">
                <div>
                    <h5>Locker Type</h5>
                    <p><?php echo htmlspecialchars($locker['locker_type']); ?></p>
                </div>
                <div>
                    <h5>Rent Duration</h5>
                    <p><?php echo htmlspecialchars($today . " to " . $endDate); ?></p>
                </div>
                <div class="price">
                    <h5>Price</h5>
                    <p><img src="../images/Saudi_Riyal_Symbol.svg.webp"
                            alt="Saudi Riyal"><?php echo htmlspecialchars($locker['locker_rentPrice']); ?></p>
                </div>
            </div>
        </section>

        <!-- --------------------[Student Details] -------------------------------->
        <!-- this std data is from database -->
        <section class="student-data">
            <h2><img src="../images/user icon.png" alt="Student Icon" class="icon"> Student Information</h2>

            <div class="details-container">
                <div>
                    <h5>Name</h5>
                    <p><?php echo htmlspecialchars($studentDetails['S_Fname'] . ' ' . $studentDetails['S_Lname']); ?>
                    </p>
                </div>

                <div>
                    <h5>Student ID</h5>
                    <p><?php echo htmlspecialchars($studentDetails['Student_ID']); ?></p>
                </div>

                <div>
                    <h5>College</h5>
                    <p><?php echo htmlspecialchars($studentDetails['S_Collage']); ?></p>
                </div>
                <div>
                    <h5>Phone Number</h5>
                    <p><?php echo htmlspecialchars($studentDetails['S_PhoneNumber']); ?></p>
                </div>

                <div class="email">
                    <h5>Email</h5>
                    <p><?php echo htmlspecialchars($studentDetails['S_Email']); ?></p>
                </div>
            </div>
        </section>


        <!-- --------------------[Payment Button] -------------------------------->
        <!-- the form is to submit the locker number to the payment page to updatae the db if the payment is suuccesful -->
        <form method="POST" action="lockersPayment.php">
            <input type="hidden" name="locker_number" value="<?php echo htmlspecialchars($locker['locker_number']); ?>">
            <button type="submit" class="btn" id="payment-btn">Proceed to Payment</button>
        </form>

    </div>

    <!-- --------------------[Footer] -------------------------------->
    <footer>
        <p>&copy; 2025 FastReach | All Rights Reserved</p>
    </footer>
</body>

</html>