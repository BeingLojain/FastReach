<?php
session_start();
require '../include/db_connect.php';

$admin_id = $_SESSION['Admin_ID'];

  $defaultEndDate = '';
  $query = "select end_date from academic_year where is_current = 1";
  $result = $conn->query($query);
  if ($row = $result->fetch_assoc()) {
      $defaultEndDate = $row['end_date'];
  }
  ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FastReach - Locker Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <style>
    body {
        font-family: 'Times New Roman', sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
        min-height: 94.5vh;
    }

    .container {
        max-width: 1200px;
        margin: 40px auto;
        padding: 30px;
        background: rgba(255, 255, 255, 0.75);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        border-radius: 20px;
        backdrop-filter: blur(12px);
    }

    h1 {
        all: unset;
        display: block;
        font-family: 'Times New Roman', serif;
        font-size: 2rem;
        font-weight: bold;
        color: #333;
        text-align: center;
        margin-bottom: 40px;
    }


    .actions {
        text-align: center;
        margin-bottom: 30px;
    }

    .btn {
        display: inline-block;
        margin: 10px;
        padding: 12px 24px;
        background-color: #243b4a;
        color: white;
        border: none;
        border-radius: 12px;
        text-decoration: none;
        font-size: 16px;
        transition: background 0.3s ease;
    }

    .btn:hover {
        background-color: #6B8494;
    }

    .back-btn {
        margin-top: 25px;
        text-align: left;
    }

    .back-btn a {
        text-decoration: none;
        color: #3E4C59;
        font-weight: bold;
        font-size: 15px;
        border: 1px solid #6B8494;
        padding: 8px 16px;
        border-radius: 10px;
        transition: 0.3s;
    }

    .back-btn a:hover {
        background: #6B8494;
        color: white;
    }

    .form-card {
        background: rgba(255, 255, 255, 0.95);
        padding: 30px 40px;
        border-radius: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        margin-top: 40px;
    }

    .form-card h4 {
        font-weight: bold;
        color: #2d3c47;
    }

    .btn,
    .btn-sm,
    .btn-primary,
    .btn-success,
    .btn-dark {
        transition: transform 0.25s ease;
    }

    .btn:hover,
    .btn-sm:hover,
    .btn-primary:hover,
    .btn-success:hover,
    .btn-dark:hover {
        transform: scale(1.03);
    }

    .btn i {
        transition: transform 0.2s ease-in-out;
    }

    .btn:hover i {
        transform: scale(1.07);
        color: #ffffffcc;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }
    </style>
</head>

<body>
    <div class="container">
    <div class="back-btn">
      <a href="../Admin/admin_dashboard.php">← Back</a>
    </div>
        <h1>Locker Management Dashboard</h1>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <select id="statusFilter" class="form-select" style="width: 200px;">
                <option value="all">All Lockers</option>
                <option value="Available">Available</option>
                <option value="Rented">Rented</option>
            </select>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addLockerModal">
                <i class="fas fa-plus me-1"></i> Add Locker
            </button>
        </div>
        <table class="table table-bordered table-hover text-center shadow-sm">
            <thead class="table-dark">
                <tr>
                    <th>Locker Number</th>
                    <th>Status</th>
                    <th>College</th>
                    <th>Section</th>
                    <th>Block</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Student</th>
                    <th>Rent Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="lockersTableBody"></tbody>
        </table>

        <!-- ==================[Add academec year form]================ -->
        <div class="form-card mt-5">
            <h4>Add an Academic Year</h4>
            <form method="POST" action="lockerController.php?action=addAcademicYear">
                <label for="label" class="form-label">Academic Year Label</label>
                <input type="text" class="form-control" id="label" name="label" placeholder="e.g. 2024–2025" required>
                <div class="form-row mt-3">
                    <div class="col">
                        <label for="start_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" required>
                    </div>
                    <div class="col">
                        <label for="end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-dark mt-3">Save</button>
            </form>
        </div>
    </div>

    <!-- ================================[Add Locker Modal] ==========================================-->
    <div class="modal fade" id="addLockerModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg border-0 rounded-4" style="background: #fff;">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title">
                        <i class="fas fa-lock me-2 text-secondary"></i> Add New Locker
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body pt-0">
                    <form id="addLockerForm">
                        <div class="mb-3">
                            <label for="lockerNumber" class="form-label">Locker Number</label>
                            <input type="text" class="form-control" id="lockerNumber" required>
                        </div>

                        <div class="mb-3">
                            <label for="lockerStatus" class="form-label">Status</label>
                            <select class="form-select" id="lockerStatus" required>
                                <option value="">Select Status</option>
                                <option value="Available">Available</option>
                                <option value="Rented">Rented</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="lockerCollege" class="form-label">College</label>
                            <select class="form-select" id="lockerCollege" required>
                                <option value="">Select College</option>
                                <option>College of Medicine</option>
                                <option>College of Dentistry</option>
                                <option>College of Nursing</option>
                                <option>College of Applied Medical Sciences</option>
                                <option>College of Clinical Pharmacy</option>
                                <option>College of Public Health</option>
                                <option>College of Architecture and Planning</option>
                                <option>College of Design</option>
                                <option>College of Engineering</option>
                                <option>College of Applied Studies and Community Service</option>
                                <option>College of Business Administration</option>
                                <option>College of Computer Science and Information Technology</option>
                                <option>College of Science</option>
                                <option>College of Science and Human Studies</option>
                                <option>College of Arts</option>
                                <option>College of Education</option>
                                <option>College of Sharia and Law</option>
                            </select>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="lockerSection" class="form-label">Section</label>
                                <input type="text" class="form-control" id="lockerSection">
                            </div>
                            <div class="col">
                                <label for="lockerBlock" class="form-label">Block</label>
                                <input type="text" class="form-control" id="lockerBlock">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Locker Type</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="lockerType" id="typeKey" value="Key"
                                    checked>
                                <label class="form-check-label" for="typeKey">Key</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="lockerType" id="typeElectronic"
                                    value="Electronic">
                                <label class="form-check-label" for="typeElectronic">Electronic</label>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="lockerPrice" class="form-label">Rent Price</label>
                                <input type="number" class="form-control" id="lockerPrice">
                            </div>
                            <div class="col">
                                <label for="lockerAdmin" class="form-label">Assign Admin</label>
                                <select class="form-select" id="lockerAdmin" required>
                                    <option value="">Assign Admin</option>

                                    <!-- Read the admins ids from db to assign an admin -->
                                    <?php
                                        include '../include/db_connect.php'; 
                                        $adminQuery = "SELECT admin_id, A_Fname, A_Lname FROM admin";
                                        $adminResult = $conn->query($adminQuery);
                                        if ($adminResult->num_rows > 0) {
                                            while ($admin = $adminResult->fetch_assoc()) {
                                            $adminFullName = htmlspecialchars($admin['A_Fname'] . ' ' . $admin['A_Lname']);
                                            echo "<option value='{$admin['admin_id']}'>ID: {$admin['admin_id']} - {$adminFullName}</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div id="rentalFields" style="display: none;">
                            <div class="mb-3">
                                <label for="studentId" class="form-label">Student ID</label>
                                <input type="text" class="form-control" id="studentId">
                            </div>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="rentStartDate" class="form-label">Rent Start Date</label>
                                    <input type="date" class="form-control" id="rentStartDate">
                                </div>
                                <div class="col">
                                    <label for="rentEndDate" class="form-label">Rent End Date</label>
                                    <input type="date" class="form-control" id="rentEndDate"
                                        value="<?php echo htmlspecialchars($defaultEndDate); ?>">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success w-100">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--==================================== [Edit Locker Modal] ===============================-->
    <div class="modal fade" id="editLockerModal" tabindex="-1" aria-labelledby="editLockerModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content shadow-lg border-0 rounded-4" style="background: #fff;">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title"><i class="fas fa-edit me-2 text-warning"></i> Edit Locker</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body pt-0">
                    <form id="editLockerForm">
                        <input type="hidden" name="action" value="editLocker">
                        <input type="hidden" name="lockerId" id="editLockerId">

                        <div class="mb-3">
                            <label for="editLockerNumber" class="form-label">Locker Number</label>
                            <input type="text" class="form-control" name="lockerNumber" id="editLockerNumber" required>
                        </div>

                        <div class="mb-3">
                            <label for="editLockerStatus" class="form-label">Status</label>
                            <select class="form-select" name="lockerStatus" id="editLockerStatus" required>
                                <option value="">Select Status</option>
                                <option value="Available">Available</option>
                                <option value="Rented">Rented</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="editLockerCollege" class="form-label">College</label>
                            <input type="text" class="form-control" name="lockerCollege" id="editLockerCollege"
                                required>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="editLockerSection" class="form-label">Section</label>
                                <input type="text" class="form-control" name="lockerSection" id="editLockerSection"
                                    required>
                            </div>
                            <div class="col">
                                <label for="editLockerBlock" class="form-label">Block</label>
                                <input type="text" class="form-control" name="lockerBlock" id="editLockerBlock"
                                    required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Locker Type</label><br>
                            <select class="form-select" name="lockerType" id="editLockerType" required>
                                <option value="Key">Key</option>
                                <option value="Electronic">Electronic</option>
                            </select>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="editLockerPrice" class="form-label">Rent Price</label>
                                <input type="number" step="0.01" class="form-control" name="lockerPrice"
                                    id="editLockerPrice" required>
                            </div>
                            <div class="col">
                                <label for="editLockerAdmin" class="form-label">Assign Admin</label>
                                <select class="form-select" name="lockerAdmin" id="editLockerAdmin" required>
                                    <option value="">Assign Admin</option>
                                    <?php
                  $adminQuery = "SELECT admin_id, A_Fname, A_Lname FROM admin";
                  $adminResult = $conn->query($adminQuery);
                  if ($adminResult->num_rows > 0) {
                      while ($admin = $adminResult->fetch_assoc()) {
                          $adminFullName = htmlspecialchars($admin['A_Fname'] . ' ' . $admin['A_Lname']);
                          echo "<option value='{$admin['admin_id']}'>ID: {$admin['admin_id']} - {$adminFullName}</option>";
                      }
                  }
                ?>
                                </select>
                            </div>
                        </div>

                        <!-- Rented Fields -->
                        <div id="editRentalFields" style="display: none;">
                            <div class="mb-3">
                                <label for="editStudentId" class="form-label">Student ID</label>
                                <input type="text" class="form-control" name="studentId" id="editStudentId">
                            </div>
                            <div class="row mb-3">
                                <div class="col">
                                    <label for="editRentStartDate" class="form-label">Rent Start Date</label>
                                    <input type="date" class="form-control" name="rentStartDate" id="editRentStartDate">
                                </div>
                                <div class="col">
                                    <label for="editRentEndDate" class="form-label">Rent End Date</label>
                                    <input type="date" class="form-control" name="rentEndDate" id="editRentEndDate">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success w-100">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    const defaultEndDate = <?php echo json_encode($defaultEndDate); ?>;

    function loadLockerStats() {
        fetch('lockerController.php?action=getStats')
            .then(res => res.json())
            .then(data => {
                document.getElementById('totalLockers').textContent = data.total || 0;
                document.getElementById('availableLockers').textContent = data.available || 0;
                document.getElementById('rentedLockers').textContent = data.rented || 0;
            });
    }

    function renderTable() {
        fetch('lockerController.php?action=getLockers&status=' + encodeURIComponent(document.getElementById(
                'statusFilter').value))
            .then(res => res.json())
            .then(lockers => {
                const tbody = document.getElementById('lockersTableBody');
                tbody.innerHTML = '';
                lockers.forEach(locker => {
                    tbody.innerHTML += `
      <tr>
        <td>${locker.locker_number || '-'}</td>
        <td>${locker.locker_status || '-'}</td>
        <td>${locker.locker_college || '-'}</td>
        <td>${locker.locker_section || '-'}</td>
        <td>${locker.locker_block || '-'}</td>
        <td>${locker.locker_type || '-'}</td>
        <td>${locker.locker_rentPrice || '0.00'}</td>
        <td>${locker.user || '-'}</td>
        <td>${locker.rent_startDate || '-'}</td>
        <td>
          <button class="btn btn-warning btn-sm" style="padding: 10px 15px; font-size: 0.75rem;" onclick='editLocker(${JSON.stringify(locker)})'><i class="fas fa-edit"></i></button>
          <button class="btn btn-danger btn-sm" style="padding: 10px 15px; font-size: 0.75rem;" onclick="deleteLocker(${locker.locker_id})"><i class="fas fa-trash-alt"></i></button>

        </td>
      </tr>`;
                });
            });
    }

    function deleteLocker(id) {
        if (!confirm('Are you sure you want to delete this locker?')) return;
        fetch('lockerController.php?action=deleteLocker', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'id=' + encodeURIComponent(id)
            })
            .then(res => res.text())
            .then(msg => {
                alert(msg);
                renderTable();
                loadLockerStats();
            });
    }

    function editLocker(locker) {
        document.getElementById('editLockerId').value = locker.locker_id;
        document.getElementById('editLockerNumber').value = locker.locker_number || '';
        document.getElementById('editLockerStatus').value = locker.locker_status || 'Available';
        document.getElementById('editLockerCollege').value = locker.locker_college || '';
        document.getElementById('editLockerSection').value = locker.locker_section || '';
        document.getElementById('editLockerBlock').value = locker.locker_block || '';
        document.getElementById('editLockerType').value = locker.locker_type || 'Key';
        document.getElementById('editLockerPrice').value = locker.locker_rentPrice || '0.00';
        document.getElementById('editStudentId').value = locker.user !== '-' ? locker.user : '';
        document.getElementById('editRentStartDate').value = locker.rent_startDate !== '-' ? locker.rent_startDate : '';
        document.getElementById('editRentEndDate').value = locker.rent_endDate && locker.rent_endDate !== '-' ? locker
            .rent_endDate : defaultEndDate;
        document.getElementById('editLockerAdmin').value = locker.admin_id || '';

        document.getElementById('editRentalFields').style.display = locker.locker_status === 'Rented' ? 'block' :
            'none';

        const modal = new bootstrap.Modal(document.getElementById('editLockerModal'));
        modal.show();
    }

    // Show rent fields only if status is "Rented" in add form
    document.getElementById('lockerStatus').addEventListener('change', function() {
        const isRented = this.value === 'Rented';
        document.getElementById('rentalFields').style.display = isRented ? 'block' : 'none';
    });

    // Show rent fields only if status is "Rented" in edit form
    document.getElementById('editLockerStatus').addEventListener('change', function() {
        const isRented = this.value === 'Rented';
        document.getElementById('editRentalFields').style.display = isRented ? 'block' : 'none';

        if (!isRented) {
            document.getElementById('editStudentId').value = '';
            document.getElementById('editRentStartDate').value = '';
            document.getElementById('editRentEndDate').value = '';
        }
    });


    document.getElementById('addLockerForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new URLSearchParams();
        formData.append('lockerNumber', document.getElementById('lockerNumber').value);
        formData.append('lockerStatus', document.getElementById('lockerStatus').value);
        formData.append('lockerCollege', document.getElementById('lockerCollege').value);
        formData.append('lockerSection', document.getElementById('lockerSection').value);
        formData.append('lockerBlock', document.getElementById('lockerBlock').value);
        formData.append('lockerType', document.querySelector('input[name="lockerType"]:checked').value);
        formData.append('lockerPrice', document.getElementById('lockerPrice').value);
        formData.append('lockerAdmin', document.getElementById('lockerAdmin').value);

        if (document.getElementById('lockerStatus').value === 'Rented') {
            formData.append('studentId', document.getElementById('studentId').value);
            formData.append('rentStartDate', document.getElementById('rentStartDate').value);
            formData.append('rentEndDate', document.getElementById('rentEndDate').value);
        }

        fetch('lockerController.php?action=addLocker', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: formData.toString()
            })
            .then(res => res.text())
            .then(msg => {
                alert(msg);
                if (msg.includes('Success')) {
                    document.getElementById('addLockerForm').reset();
                    document.getElementById('rentalFields').style.display = 'none';
                    const modal = bootstrap.Modal.getInstance(document.getElementById('addLockerModal'));
                    modal.hide();
                    renderTable();
                    loadLockerStats();
                }
            });
    });


    document.getElementById('editLockerForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new URLSearchParams();
        formData.append('action', 'editLocker');
        formData.append('lockerId', document.getElementById('editLockerId').value);
        formData.append('lockerNumber', document.getElementById('editLockerNumber').value);
        formData.append('lockerStatus', document.getElementById('editLockerStatus').value);
        formData.append('lockerCollege', document.getElementById('editLockerCollege').value);
        formData.append('lockerSection', document.getElementById('editLockerSection').value);
        formData.append('lockerBlock', document.getElementById('editLockerBlock').value);
        formData.append('lockerType', document.getElementById('editLockerType').value);
        formData.append('lockerPrice', document.getElementById('editLockerPrice').value);
        formData.append('lockerAdmin', document.getElementById('editLockerAdmin').value);

        if (document.getElementById('editLockerStatus').value === 'Rented') {
            formData.append('studentId', document.getElementById('editStudentId').value);
            formData.append('rentStartDate', document.getElementById('editRentStartDate').value);
            formData.append('rentEndDate', document.getElementById('editRentEndDate').value);
        }

        fetch('lockerController.php?action=editLocker', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: formData.toString()
            })
            .then(res => res.text())
            .then(msg => {
                alert(msg);
                if (msg.includes('Success')) {
                    const modal = bootstrap.Modal.getInstance(document.getElementById('editLockerModal'));
                    modal.hide();
                    renderTable();
                    loadLockerStats();
                }
            });
    });

    // Auto-load lockers and stats
    document.getElementById('statusFilter').addEventListener('change', () => {
        renderTable();
    });

    window.addEventListener('DOMContentLoaded', () => {
        renderTable();
        loadLockerStats();
    });
    </script>
</body>

</html>