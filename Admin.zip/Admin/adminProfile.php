<?php
include '../include/db_connect.php';
session_start();


if (isset($_SESSION['admin_username'])) {
    $admin_username = $_SESSION['admin_username'];
    $admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

    $admin_username = $conn->real_escape_string($admin_username);

    if ($admin_id) {
        $sql = "SELECT * FROM admin WHERE Admin_ID = '$admin_id'";
    } else {
        $sql = "SELECT * FROM admin WHERE A_Username = '$admin_username'";
    }

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc(); 
    } else {
        echo "No admin records found.";
        exit();
    }
} else {
    header('Location: ../home/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Profile</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Times New Roman", sans-serif;
    }

    body {
      background: linear-gradient(to bottom right, #8d99a3, #ffffff);
      color: #333;
      height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .profile-container {
      flex: 1;
      margin: 20px;
      background: rgba(255, 255, 255, 0.95);
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      overflow-y: auto;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 40px;
    }

    .header h1 {
      font-size: 32px;
      color: #2d3c47;
    }

    .back-button {
      font-size: 16px;
      text-decoration: none;
      color: #fff;
      background-color: #76848e;
      padding: 10px 16px;
      border-radius: 10px;
      transition: 0.3s;
    }

    .back-button:hover {
      background-color: #cbd5dd;
    }

    h2 {
      font-size: 24px;
      margin-bottom: 20px;
      color: #2d3c47;
    }

    .details-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 25px;
      margin-bottom: 40px;
    }

    .details-grid div {
      background: #cbd5dd9e;
      border-radius: 12px;
      padding: 20px;
      box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.03);
    }

    h5 {
      font-size: 14px;
      color: #666;
      margin-bottom: 5px;
    }

    p {
      font-size: 16px;
      font-weight: 500;
    }

  </style>
</head>

<body>
  <div class="profile-container">
    <div class="header">
      <a href="admin_dashboard.php" class="back-button">&#8592; Back</a>
      <h1>Admin Profile</h1>
    </div>

    <h2>Admin Information</h2>
    <div class="details-grid">
      <div>
        <h5>Name</h5>
        <p><?= htmlspecialchars($admin['A_Fname'] . ' ' . $admin['A_Lname']) ?></p>
      </div>
      <div>
        <h5>Admin Username</h5>
        <p><?= htmlspecialchars($admin['A_Username']) ?></p>
      </div>
      <div>
        <h5>Admin ID</h5>
        <p><?= htmlspecialchars($admin['Admin_ID']) ?></p> 
      </div>
      <div>
        <h5>Email</h5>
        <p><?= htmlspecialchars($admin['A_Email']) ?></p>
      </div>
      <div>
        <h5>Phone Number</h5>
        <p><?= htmlspecialchars($admin['A_PhoneNumber']) ?></p>
      </div>
      <div>
        <h5>Password</h5>
        <p><?= str_repeat('*', strlen($admin['A_Password'])) ?></p>
      </div>
    </div>
  </div>
</body>
</html>
