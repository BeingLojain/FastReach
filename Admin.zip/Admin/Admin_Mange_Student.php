<?php
require '../include/db_connect.php';
$result = $conn->query("SELECT * FROM Student");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Manage Students</title>
  <style>
    body {
      font-family: 'Times New Roman', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      min-height: 94.5vh;
    }

    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 30px;
      background: rgba(255, 255, 255, 0.75);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
      border-radius: 20px;
      backdrop-filter: blur(12px);
    }

    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 40px;
    }

    .actions {
      text-align: center;
      margin-bottom: 30px;
    }

    .btn {
      display: inline-block;
      margin: 10px;
      padding: 12px 24px;
      background-color: #243b4a;
      color: white;
      border: none;
      border-radius: 12px;
      text-decoration: none;
      font-size: 16px;
      transition: background 0.3s ease;
    }

    .btn:hover {
      background-color: #162831;
    }

    .student-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 20px;
    }

    .student-card {
      background: white;
      border-radius: 15px;
      padding: 20px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
      transition: transform 0.2s;
    }

    .student-card:hover {
      transform: translateY(-5px);
    }

    .student-card h3 {
      font-size: 18px;
      margin: 0 0 10px;
      color: #222;
    }

    .student-card p {
      font-size: 14px;
      margin: 4px 0;
      color: #555;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }

  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/admin_dashboard.php">← Back</a>
    </div>
    <h1>Manage Students</h1>

    <div class="actions">
      <a href="add_student.php" class="btn">Add Student</a>
      <a href="edit_student.php" class="btn">Edit Student</a>
      <a href="delete_student.php" class="btn">Delete Student</a>
    </div>

    <div class="student-grid">
      <?php while($row = $result->fetch_assoc()): ?>
        <div class="student-card">
          <h3><?= htmlspecialchars($row['S_Fname'] . ' ' . $row['S_Lname']) ?></h3>
          <p><strong>Email:</strong> <?= htmlspecialchars($row['S_Email']) ?></p>
          <p><strong>Major:</strong> <?= htmlspecialchars($row['S_Major']) ?></p>
          <p><strong>Phone:</strong> <?= htmlspecialchars($row['S_PhoneNumber']) ?></p>
          <p><strong>City:</strong> <?= htmlspecialchars($row['City']) ?></p>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</body>
</html>