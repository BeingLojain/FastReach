<?php
require '../include/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['News_ID'];
    $conn->query("DELETE FROM News WHERE News_ID = $id");
}

$news = $conn->query("SELECT * FROM News");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete News</title>
  <style>
    body {
      font-family: 'Times New Roman', sans-serif;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      padding: 40px;
      margin: 0;
      min-height:89vh;
    }
    .container {
      max-width: 1000px;
      margin: auto;
      background: rgba(255,255,255,0.9);
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      backdrop-filter: blur(10px);
    }
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }
    .news-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #ddd;
      padding: 15px 0;
    }
    .news-left {
      display: flex;
      align-items: center;
      gap: 20px;
    }
    .news-left img {
      width: 100px;
      height: 80px;
      object-fit: cover;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .news-info {
      max-width: 600px;
    }
    .news-info strong {
      display: block;
      font-size: 16px;
      margin-bottom: 5px;
      color: #333;
    }
    .news-info a {
      font-size: 14px;
      color: #4a69bd;
      text-decoration: none;
    }
    .news-info a:hover {
      text-decoration: underline;
    }
    form button {
      background-color: #d62828;
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
    }
    form button:hover {
      background-color: #a4161a;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }
    
  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/news_dashboard.php">← Back</a>
    </div>
    <h1>Delete News</h1>
    <?php while($row = $news->fetch_assoc()): ?>
      <div class="news-item">
        <div class="news-left">
          <img src="<?= htmlspecialchars($row['News_image_url']) ?>" alt="News Image">
          <div class="news-info">
            <strong><?= htmlspecialchars($row['News_Title']) ?></strong>
            <a href="<?= htmlspecialchars($row['news_link']) ?>" target="_blank"><?= htmlspecialchars($row['news_link']) ?></a>
          </div>
        </div>
        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this news item?');">
          <input type="hidden" name="News_ID" value="<?= $row['News_ID'] ?>">
          <button type="submit">Delete</button>
        </form>
      </div>
    <?php endwhile; ?>
  </div>
</body>
</html>
