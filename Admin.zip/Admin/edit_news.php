<?php
require '../include/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['News_ID'];
    $title = $_POST['News_Title'];
    $image = $_POST['News_image_url'];
    $link = $_POST['news_link'];

    $stmt = $conn->prepare("UPDATE News SET News_Title=?, News_image_url=?, news_link=? WHERE News_ID=?");
    $stmt->bind_param("sssi", $title, $image, $link, $id);
    $stmt->execute();
    $stmt->close();
}

$news = $conn->query("SELECT * FROM News");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit News</title>
  <style>
    body {
      font-family: 'Times New Roman', serif;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      margin: 0;
      padding: 40px;
      min-height: 89vh;
    }
    .container {
      max-width: 1000px;
      margin: auto;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.1);
      backdrop-filter: blur(8px);
    }
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }
    .news-item {
      display: flex;
      align-items: center;
      gap: 20px;
      border-bottom: 1px solid #ccc;
      padding: 20px 0;
      flex-wrap: wrap;
    }
    .news-item img {
      width: 100px;
      height: 80px;
      object-fit: cover;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .form-container {
      flex: 1;
    }

    .form-row {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      flex-wrap: wrap;
      margin-bottom: 10px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      width: 30%;
    }

    .form-group label {
      font-weight: bold;
      margin-bottom: 4px;
    }

    .form-group input[type=text] {
      padding: 8px;
      border-radius: 6px;
      border: 1px solid #aaa;
      font-family: 'Times New Roman', serif;
    }

    form button {
      background-color: #243b4a;
      color: white;
      border: none;
      padding: 8px 20px;
      border-radius: 8px;
      cursor: pointer;
      font-family: 'Times New Roman', serif;
    }

    form button:hover {
      background-color: #6B8494;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }
  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/news_dashboard.php">← Back</a>
    </div>
    <h1>Edit News</h1>
    <?php while($row = $news->fetch_assoc()): ?>
      <div class="news-item">
        <img src="<?= htmlspecialchars($row['News_image_url']) ?>" alt="News Image">
        <div class="form-container">
          <form method="POST">
            <input type="hidden" name="News_ID" value="<?= $row['News_ID'] ?>">

            <div class="form-row">
              <div class="form-group">
                <label for="title<?= $row['News_ID'] ?>">Title:</label>
                <input type="text" id="title<?= $row['News_ID'] ?>" name="News_Title" value="<?= htmlspecialchars($row['News_Title']) ?>">
              </div>
              <div class="form-group">
                <label for="image<?= $row['News_ID'] ?>">Image URL:</label>
                <input type="text" id="image<?= $row['News_ID'] ?>" name="News_image_url" value="<?= htmlspecialchars($row['News_image_url']) ?>">
              </div>
              <div class="form-group">
                <label for="link<?= $row['News_ID'] ?>">Link:</label>
                <input type="text" id="link<?= $row['News_ID'] ?>" name="news_link" value="<?= htmlspecialchars($row['news_link']) ?>">
              </div>
            </div>

            <button type="submit">Save</button>
          </form>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</body>
</html>
