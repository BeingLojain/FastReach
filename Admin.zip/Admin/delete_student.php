<?php
require '../include/db_connect.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_student'])) {
    $delete_id = intval($_POST['selected_id']);
    $stmt = $conn->prepare("DELETE FROM Student WHERE Student_ID = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location:../Admin/Admin_Mange_Student.php");
    exit();
}

$students = $conn->query("SELECT Student_ID, S_Fname, S_Lname FROM Student");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete Student</title>
  <style>
    body {
      font-family: 'Times New Roman', sans-serif;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 700px;
      margin: 40px auto;
      background: rgba(255, 255, 255, 0.9);
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 20px;
      align-items: center;
    }

    label {
      font-weight: bold;
      font-size: 16px;
      color: #444;
      width: 100%;
      text-align: center;
    }

    select {
      width: 100%;
      max-width: 400px;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #aaa;
      font-size: 15px;
    }

    button {
      padding: 12px 30px;
      font-size: 16px;
      background: #a92d2d;
      color: white;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-family: 'Times New Roman', sans-serif;
    }

    button:hover {
      background: #751c1c;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }
  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/Admin_Mange_Student.php">← Back</a>
    </div>

    <h1>Delete Student</h1>

    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this student?');">
      <label>Select Student to Delete:</label>
      <select name="selected_id" required>
        <option value="">--Choose a student--</option>
        <?php while($row = $students->fetch_assoc()): ?>
          <option value="<?= $row['Student_ID'] ?>">
            <?= $row['S_Fname'] . ' ' . $row['S_Lname'] ?> (<?= $row['Student_ID'] ?>)
          </option>
        <?php endwhile; ?>
      </select>

      <button type="submit" name="delete_student">Delete Student</button>
    </form>
  </div>
</body>
</html>