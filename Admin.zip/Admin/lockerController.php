<?php

session_start();
include('../include/db_connect.php');
$admin_id = $_SESSION['Admin_ID'];
if (!isset($_SESSION['admin_username']) || !isset($_SESSION['Admin_ID'])) {
    echo json_encode(['status' => 'error', 'message' => 'Session expired']);
    exit();
}

$action = $_GET['action'] ?? '';

// Get All Lockers 
if ($action === 'getLockers') {
    $status = $_GET['status'] ?? 'all';

    if ($status === 'all') {
        $query = "SELECT * FROM locker";
        $stmt = $conn->prepare($query);
    } else {
        $query = "SELECT * FROM locker WHERE locker_status = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $status);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $lockers = [];

    while ($row = $result->fetch_assoc()) {
        $lockers[] = [
            'locker_id' => $row['locker_id'],
            'locker_number' => $row['locker_number'],
            'locker_status' => $row['locker_status'],
            'locker_college' => $row['locker_college'],
            'locker_section' => $row['locker_section'],
            'locker_block' => $row['locker_block'],
            'locker_type' => $row['locker_type'],
            'locker_rentPrice' => $row['locker_rentPrice'],
            'rent_startDate' => $row['rent_startDate'] ?? '-',
            'user' => $row['std_id'] ?? '-'
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($lockers);
    exit;
}


// add new locker
if ($action === 'addLocker') {
    $number = $_POST['lockerNumber'] ?? '';
    $status = $_POST['lockerStatus'] ?? '';
    $college = $_POST['lockerCollege'] ?? '';
    $section = $_POST['lockerSection'] ?? '';
    $block = $_POST['lockerBlock'] ?? '';
    $type = $_POST['lockerType'] ?? 'Key';
    $price = $_POST['lockerPrice'] ?? '0.00';
    $adminId = $_POST['lockerAdmin'] ?? null;
    $studentId = $_POST['studentId'] ?? null;
    $rentStart = $_POST['rentStartDate'] ?? null;
    $rentEnd = $_POST['rentEndDate'] ?? null;

    if ($number && $status && $adminId) {
        // check if the number locker already exist in colleage
        $checkLockerQuery = "select * from locker where locker_number = ? AND locker_college = ?";
        $stmt = $conn->prepare($checkLockerQuery);
        $stmt->bind_param("ss", $number, $college);
        $stmt->execute();
        $existingLocker = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($existingLocker){
            echo "Error: Locker number already exists in this college.";
            exit;
        }

        // check if block already has 4 lockers in the same collage
        $checkBlockQuery= "SELECT COUNT(*) FROM locker WHERE locker_block = ? AND locker_college = ?";
        $stmt= $conn->prepare($checkBlockQuery);
        $stmt->bind_param("ss", $block, $college);
        $stmt->execute();
        $blockCount = $stmt->get_result()->fetch_row()[0];
        $stmt->close();

        if ($blockCount >= 4){
            echo "Error: Block already has 4 lockers in this college.";
            exit;
        }

        //current academic year data
        $yearQuery = "SELECT year_id, end_date FROM academic_year WHERE is_current = 1 LIMIT 1";
        $result = $conn->query($yearQuery);
        $currentYear = $result->fetch_assoc();
        $academicYearId = $currentYear['year_id'] ?? null;
        $defaultEndDate = $currentYear['end_date'] ?? null;

        if ($status === 'Rented'){ // the added lokcer is rented

            // check if std id does exist in std table
            $checkStudentQuery= "SELECT 1 FROM student WHERE Student_ID = ?";
            $stmt= $conn->prepare($checkStudentQuery);
            $stmt->bind_param("s", $studentId);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows === 0){
                echo "Error: Student ID does not exist.";
                $stmt->close();
                exit;
            }
            $stmt->close();

            //check std not already have a locker
            $checkStudentLockerQuery= "SELECT 1 FROM locker WHERE std_id = ?";
            $stmt= $conn->prepare($checkStudentLockerQuery);
            $stmt->bind_param("s", $studentId);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0){
                echo "Error: This student already has a locker.";
                $stmt->close();
                exit;
            }
            $stmt->close();

            //default rent end date from acadiemic year
            $rentEnd = $rentEnd ?? $defaultEndDate;

            $stmt = $conn->prepare("INSERT INTO locker 
                (locker_number, locker_status, locker_college, locker_section, locker_block, locker_type, locker_rentPrice, admin_id, std_id, rent_startDate, rent_endDate) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssdiiss", $number, $status, $college, $section, $block, $type, $price, $adminId, $studentId, $rentStart, $rentEnd);
        } else {
            $stmt = $conn->prepare("INSERT INTO locker 
            (locker_number, locker_status, locker_college, locker_section, locker_block, locker_type, locker_rentPrice, admin_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssdi", $number, $status, $college, $section, $block, $type, $price, $adminId);
        }

        if ($stmt->execute()) {
            echo "Success: Locker added.";
        } else {
            echo "Error: Could not add locker. " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error: Missing required fields.";
    }
    exit;
}




//Delete Locker
if ($action === 'deleteLocker') {
    $id = $_POST['id'] ?? '';
    if ($id) {
        $stmt = $conn->prepare("DELETE FROM locker WHERE locker_id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "Locker deleted successfully.";
        } else {
            echo "Error: Could not delete locker.";
        }
    } else {
        echo "Error: Missing locker ID.";
    }
    exit;
}

// ===== Edit Locker =====
if ($action === 'editLocker') {
    $lockerId = $_POST['lockerId'] ?? '';
    $number = $_POST['lockerNumber'] ?? '';
    $status = $_POST['lockerStatus'] ?? '';
    $college = $_POST['lockerCollege'] ?? '';
    $section = $_POST['lockerSection'] ?? '';
    $block = $_POST['lockerBlock'] ?? '';
    $type = $_POST['lockerType'] ?? 'Key';
    $price = $_POST['lockerPrice'] ?? '0.00';
    $adminId = $_POST['lockerAdmin'] ?? null;
    $studentId = $_POST['studentId'] ?? null;
    $rentStart = $_POST['rentStartDate'] ?? null;
    $rentEnd = $_POST['rentEndDate'] ?? null;

    if (!$lockerId || !$number || !$status || !$adminId) {
        echo "Error: Missing required fields.";
        exit;
    }

    // check if number locker does already exist in collage (not include the current locker)
    $stmt= $conn->prepare("SELECT locker_id FROM locker WHERE locker_number = ? AND locker_college = ? AND locker_id != ?");
    $stmt->bind_param("ssi", $number, $college, $lockerId);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0){
        echo "Error: Locker number already exists in this college.";
        $stmt->close();
        exit;
    }
    $stmt->close();

    // check if block already has 4 lockers in the same collage
    $stmt= $conn->prepare("SELECT COUNT(*) FROM locker WHERE locker_college = ? AND locker_section = ? AND locker_block = ? AND locker_id != ?");
    $stmt->bind_param("sssi", $college, $section, $block, $lockerId);
    $stmt->execute();
    $stmt->bind_result($blockCount);
    $stmt->fetch();
    $stmt->close();

    if ($blockCount >= 4){
        echo "Error: Block already has 4 lockers in this college.";
        exit;
    }

    
    if ($status === 'Rented') { // edit locker to rented

        // ensure std id if rented
        if (!$studentId) {
            echo "Error: Student ID is required when status is Rented.";
            exit;
        }

        // check if std id does exist
        $stmt= $conn->prepare("SELECT 1 FROM student WHERE Student_ID = ?");
        $stmt->bind_param("s", $studentId);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 0){
            echo "Error: Student ID does not exist.";
            $stmt->close();
            exit;
        }
        $stmt->close();

        // check if std has a locker renttted already
        $stmt= $conn->prepare("select 1 from locker where std_id = ? and locker_id != ?");
        $stmt->bind_param("si", $studentId, $lockerId);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0){
            echo "Error: This student already has a locker.";
            $stmt->close();
            exit;
        }
        $stmt->close();

        // update data on db
        $stmt = $conn->prepare("UPDATE locker SET 
            locker_number = ?, locker_status = ?, locker_college = ?, locker_section = ?, 
            locker_block = ?, locker_type = ?, locker_rentPrice = ?, admin_id = ?, 
            std_id = ?, rent_startDate = ?, rent_endDate = ? 
            WHERE locker_id = ?");
        $stmt->bind_param("ssssssdisssi", $number, $status, $college, $section, $block, $type, $price, $adminId, $studentId, $rentStart, $rentEnd, $lockerId);
    } else {
        // if change from rented to available then delete data from db
        $stmt = $conn->prepare("UPDATE locker SET 
            locker_number = ?, locker_status = ?, locker_college = ?, locker_section = ?, 
            locker_block = ?, locker_type = ?, locker_rentPrice = ?, admin_id = ?, 
            std_id = NULL, rent_startDate = NULL, rent_endDate = NULL 
            WHERE locker_id = ?");
        $stmt->bind_param("ssssssdii", $number, $status, $college, $section, $block, $type, $price, $adminId, $lockerId);
    }

    if ($stmt->execute()) {
        echo "Success: Locker updated.";
    } else {
        echo "Error: Could not update locker. " . $stmt->error;
    }

    $stmt->close();
    exit;
}

// ===== Add Academic Year =====
if ($action === 'addAcademicYear') {
    $label = $_POST['label'] ?? '';
    $start = $_POST['start_date'] ?? '';
    $end = $_POST['end_date'] ?? '';
    $admin_id = $_SESSION['Admin_ID'] ?? null;

    if (!$admin_id) {
        echo "<script>alert('Session expired. Please log in again.');window.location.href = 'login.php';</script>";
        exit;
    }

    // check if required fields are entered
    if ($label && $start && $end){
        
        // match dates with year label
        if (preg_match('/^(\d{4})\s*[–-]\s*(\d{4})$/', $label, $matches)) {
            $labelStartYear = $matches[1];
            $labelEndYear = $matches[2];
// change the start and end dates to year only
            $actualStartYear = date('Y', strtotime($start));
            $actualEndYear = date('Y', strtotime($end));

            // check if label years match the start and end dates
            if ($labelStartYear != $actualStartYear || $labelEndYear != $actualEndYear){
                echo "<script>alert('Label years do not match start and end dates.');window.location.href = 'AdminLockers.php'; </script>";
                exit;
            }
        } else {
            echo "<script>alert('Invalid label format. Use format like 2023–2024.');window.location.href = 'AdminLockers.php'; </script>";
            exit;
        }

        // check if the entered year is current
        $today = date('Y-m-d');
        $isCurrent = ($start <= $today && $today <= $end) ? 1 : 0;

        // if the entered year is current change other years to not current
        if ($isCurrent) {
            $conn->query("UPDATE academic_year SET is_current = 0");
        }

        // insert academic year to db
        $stmt = $conn->prepare("INSERT INTO academic_year (label, start_date, end_date, admin_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $label, $start, $end, $admin_id);
        if ($stmt->execute()) {
            echo "<script>alert('Academic year added successfully!');window.location.href = 'AdminLockers.php';</script>";
        } else {
            echo "<script>alert('Error adding academic year.');window.location.href = 'AdminLockers.php';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Please fill in all fields.'); window.location.href = 'AdminLockers.php';</script>";
    }

    exit;
}

echo "Invalid action.";
?>