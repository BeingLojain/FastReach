<?php
session_start();
require '../include/db_connect.php';

$admin_id = $_SESSION['Admin_ID'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['Student_ID'];
    $email = $_POST['S_Email'];
    $phone = $_POST['S_PhoneNumber'];

    if (!is_numeric($student_id)) {
        echo "<script>alert('Student ID must be a number.'); window.history.back();</script>"; exit();
    }

    $checkID = $conn->prepare("SELECT 1 FROM Student WHERE Student_ID = ?");
    $checkID->bind_param("i", $student_id);
    $checkID->execute();
    $checkID->store_result();
    if ($checkID->num_rows > 0) {
        echo "<script>alert('Student ID already exists.'); window.history.back();</script>"; exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format.'); window.history.back();</script>"; exit();
    }

    $checkEmail = $conn->prepare("SELECT 1 FROM Student WHERE S_Email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();
    if ($checkEmail->num_rows > 0) {
        echo "<script>alert('Email already in use.'); window.history.back();</script>"; exit();
    }

    if (!preg_match('/^[0-9]{10}$/', $phone)) {
        echo "<script>alert('Phone number must be 10 digits.'); window.history.back();</script>"; exit();
    }

    $checkPhone = $conn->prepare("SELECT 1 FROM Student WHERE S_PhoneNumber = ?");
    $checkPhone->bind_param("s", $phone);
    $checkPhone->execute();
    $checkPhone->store_result();
    if ($checkPhone->num_rows > 0) {
        echo "<script>alert('Phone number already in use.'); window.history.back();</script>"; exit();
    }

    // Insert
    $fname = $_POST['S_Fname'];
    $lname = $_POST['S_Lname'];
    $major = $_POST['S_Major'];
    $gender = $_POST['S_Gender'];
    $password = $_POST['S_Password'];
    $collage = $_POST['S_Collage'];
    $bank = $_POST['S_BankAccount'];
    $street = $_POST['Street_Name'];
    $city = $_POST['City'];
    $postal = $_POST['Postal_Code'];

    $stmt = $conn->prepare("INSERT INTO Student (Student_ID, S_Fname, S_Lname, S_Email, S_Major, S_Gender, S_Password, S_PhoneNumber, S_Collage, S_BankAccount, Street_Name, City, Postal_Code, Admin_ID)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssssssssi", $student_id, $fname, $lname, $email, $major, $gender, $password, $phone, $collage, $bank, $street, $city, $postal, $admin_id);
    $stmt->execute();

    echo "<script>alert('Student added successfully!'); window.location.href = '../Admin/Admin_Mange_Student.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Student</title>
  <style>
    body {
      font-family: 'Times New Roman', sans-serif;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      background: rgba(255, 255, 255, 0.85);
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }

    form {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 15px;
    }

    label {
      display: flex;
      flex-direction: column;
      font-weight: bold;
      font-size: 14px;
      color: #444;
    }

    input, select {
      padding: 10px;
      margin-top: 5px;
      border-radius: 8px;
      border: 1px solid #aaa;
    }

    input[readonly] {
      background-color: #f2f2f2;
    }

    button {
      grid-column: span 2;
      margin-top: 20px;
      padding: 12px;
      font-size: 16px;
      background: #243b4a;
      color: white;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-family: 'Times New Roman', sans-serif;
    }

    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }

  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/Admin_Mange_Student.php">← Back</a>
    </div>

    <h1>Add New Student</h1>

    <form method="POST">
      <label>Student ID:
        <input type="number" name="Student_ID" id="studentId" required oninput="generateEmail()">
      </label>

      <label>First Name:
        <input type="text" name="S_Fname" required>
      </label>

      <label>Last Name:
        <input type="text" name="S_Lname" required>
      </label>

      <label>Email:
        <input type="email" name="S_Email" id="emailField" readonly required>
      </label>

      <label>Major:
        <input type="text" name="S_Major" required>
      </label>

      <label>Gender:
        <select name="S_Gender" required>
          <option value="">Select</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </select>
      </label>

      <label>Password:
        <input type="text" name="S_Password" required>
      </label>

      <label>Phone Number:
        <input type="text" name="S_PhoneNumber" required>
      </label>

      <label>College:
        <select name="S_Collage" required>
          <option value="">Select</option>
          <option value="College of Science and Human Studies">College of Science and Human Studies</option>
          <option value="College of Business">College of Business</option>
          <option value="College of Public Health">College of Public Health</option>
          <option value="College of Nursing">College of Nursing</option>
          <option value="College of Arts">College of Arts</option>
          <option value="College of Medicine">College of Medicine</option>
        </select>
      </label>


      <label>Bank Account:
        <input type="text" name="S_BankAccount" required>
      </label>

      <label>Street Name:
        <input type="text" name="Street_Name" required>
      </label>

      <label>City:
        <input type="text" name="City" required>
      </label>

      <label>Postal Code:
        <input type="text" name="Postal_Code" required>
      </label>

      <button type="submit">Add Student</button>
    </form>
  </div>

  <script>
    function generateEmail() {
      const id = document.getElementById('studentId').value.trim();
      const emailField = document.getElementById('emailField');
      emailField.value = id ? `${id}@iau.edu.sa` : '';
    }
  </script>
</body>
</html>