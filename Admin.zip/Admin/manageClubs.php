<?php
include('../include/db_connect.php');
$action = false;

$type = $_GET['type'] ?? 'club';
$table = $type === 'club' ? 'Club' : 'Workshop';
$id_field = $type === 'club' ? 'Club_ID' : 'Workshop_ID';
$name_field = $type === 'club' ? 'Club_name' : 'Workshop_name';
$image_field = $type === 'club' ? 'club_image_URL' : 'Workshop_image_URL';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
  $name = $_POST['name'];
  $desc = $_POST['description'];
  $link = $_POST['registration_link'];
  $image = '';

  if (isset($_FILES['image']) && $_FILES['image']['name']) {
    $upload_dir = 'uploads/';
    if (!file_exists($upload_dir)) mkdir($upload_dir, 0777, true);

    $image_name = basename($_FILES['image']['name']);
    $image = $upload_dir . $image_name;
    $tmp_name = $_FILES['image']['tmp_name'];

    if (!move_uploaded_file($tmp_name, $image)) {
      echo "<script>toastr.error('Image upload failed');</script>";
      $image = '';
    }
  }

  if ($_POST['save'] === 'Save') {
    if ($type === 'club') {
      $club_leader = $_POST['club_leader'];
      $meeting_schedule = $_POST['meeting_schedule'];
      $contact = $_POST['contact'];
      
      $sql = "INSERT INTO $table (`$name_field`, description, Registration_link, `$image_field`, 
              club_leader, meeting_schedule, contact) 
              VALUES ('$name', '$desc', '$link', '$image', '$club_leader', '$meeting_schedule', '$contact')";
    } else {
      $club_id = $_POST['club_id'];
      
      $sql = "INSERT INTO $table (`$name_field`, description, Registration_link, `$image_field`, Club_ID) 
              VALUES ('$name', '$desc', '$link', '$image', '$club_id')";
    }
    mysqli_query($conn, $sql);
    $action = "add";
  } elseif ($_POST['save'] === 'Update') {
    $id = intval($_POST['id']);
    
    if ($type === 'club') {
      $club_leader = $_POST['club_leader'];
      $meeting_schedule = $_POST['meeting_schedule'];
      $contact = $_POST['contact'];
      
      $sql = "UPDATE $table SET 
              `$name_field`='$name', 
              description='$desc', 
              Registration_link='$link',
              club_leader='$club_leader',
              meeting_schedule='$meeting_schedule',
              contact='$contact'" .
              ($image ? ", `$image_field`='$image'" : "") . 
              " WHERE $id_field=$id";
    } else {
      $club_id = $_POST['club_id'];
      
      $sql = "UPDATE $table SET 
              `$name_field`='$name', 
              description='$desc', 
              Registration_link='$link',
              Club_ID='$club_id'" .
              ($image ? ", `$image_field`='$image'" : "") . 
              " WHERE $id_field=$id";
    }
    mysqli_query($conn, $sql);
    $action = "edit";
  }
}


//Delet

if (isset($_GET['action']) && $_GET['action'] == 'del') {
  $id = intval($_GET['id']);
  $sql = "DELETE FROM $table WHERE $id_field = $id";
  mysqli_query($conn, $sql);
  $action = "del";
}

// For workshops, join with clubs to get club name
if ($type === 'workshop') {
  $items = mysqli_query($conn, "SELECT w.*, c.Club_name as associated_club 
                               FROM $table w 
                               LEFT JOIN Club c ON w.Club_ID = c.Club_ID");
} else {
  $items = mysqli_query($conn, "SELECT * FROM $table");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="admin.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
  <title>Admin - <?= ucfirst($type) ?>s</title>
  <style> 
  
  /* ========== Back Btn ========== */

  .back-btn {
    width: 100%;
    max-width: 1100px;
    display: flex;
    justify-content: flex-start;
    margin-bottom: 10px;
}

.back-link {
    text-decoration: none;
    color: #243b4a;
    font-weight: bold;
    border: 1px solid #243b4a;
    padding: 8px 14px;
    border-radius: 8px;
    transition: 0.3s;
}

.back-link:hover {
    background-color: #243b4a;
    color: white;
}
</style>
</head>
<body>
<div class="admin-dashboard">
  <div class="admin-card">
  <div class="back-btn">
      <a href="../Admin/admin_dashboard.php" class="back-link">← Back</a>
    </div>
    <div class="admin-header">
      <h1 class="admin-title"><?= ucfirst($type) ?> Management</h1>
      <div class="admin-top-bar">
        <form method="get" class="mb-0">
          <select name="type" onchange="this.form.submit()" class="admin-dropdown">
            <option value="club" <?= $type == 'club' ? 'selected' : '' ?>>Clubs</option>
            <option value="workshop" <?= $type == 'workshop' ? 'selected' : '' ?>>Workshops</option>
          </select>
        </form>

        <a href="add_club.php?type=<?= $type ?>" class="add-btn">Add New</a>
      </div>
    </div>

    <table class="admin-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Description</th>
          <?php if ($type === 'club'): ?>
            <th>Leader</th>
            <th>Schedule</th>
            <th>Contact</th>
          <?php else: ?>
            <th>Associated Club</th>
          <?php endif; ?>
          <th>Registration</th>
          <th>Image</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>

      <!-- view club INfo from Database-->
        <?php while ($item = $items->fetch_assoc()) { ?>
        <tr>
          <td><?= $item[$name_field] ?></td>
          <td><?= substr($item['description'], 0, 100) . (strlen($item['description']) > 100 ? '...' : '') ?></td>
          <?php if ($type === 'club'): ?>
            <td><?= $item['club_leader'] ?></td>
            <td><?= $item['meeting_schedule'] ?></td>
            <td><?= $item['contact'] ?></td>
          <?php else: ?>
            <td><?= $item['associated_club'] ?></td>
          <?php endif; ?>
          <td>
            <a href="<?= $item['Registration_link'] ?>" target="_blank" class="text-decoration-none">
              <i data-feather="external-link"></i>
            </a>
          </td>
          <td>
            <?php if (!empty($item[$image_field])): ?>
              <?php 
                $image_path = $item[$image_field];
                if (filter_var($image_path, FILTER_VALIDATE_URL)) {
                  $image_src = $image_path;
                } else {
                  $image_src = './' . $image_path;
                }
              ?>
              <img src="<?= $image_src ?>" alt="<?= $item[$name_field] ?>" class="admin-table-img">
            <?php else: ?>
              <span class="text-muted">No Image</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="action-buttons">
              <a href="add_club.php?action=edit&type=<?= $type ?>&id=<?= $item[$id_field] ?>">
                <i data-feather="edit-2"></i>
              </a>
              <i onclick="confirm_delete(<?= $item[$id_field] ?>)" data-feather="trash-2" style="cursor:pointer;"></i>
            </div>
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
<script>
  feather.replace();

  function confirm_delete(id) {
    if (confirm('Are you sure you want to delete this item?')) {
      window.location.href = "manageClubs.php?type=<?= $type ?>&action=del&id=" + id;
    }
  }

  <?php if ($action): ?>
    <?php if ($action == 'add'): ?>
      toastr.success("<?= ucfirst($type) ?> was added successfully");
    <?php elseif ($action == 'edit'): ?>
      toastr.info("<?= ucfirst($type) ?> was updated successfully");
    <?php elseif ($action == 'del'): ?>
      toastr.error("<?= ucfirst($type) ?> was deleted");
    <?php endif; ?>
  <?php endif; ?>
</script>
</body>
</html>