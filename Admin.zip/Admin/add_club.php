<?php
include('../include/db_connect.php');

$type = $_GET['type'] ?? 'club';
$table = $type === 'club' ? 'Club' : 'Workshop';
$id_field = $type === 'club' ? 'Club_ID' : 'Workshop_ID';
$name_field = $type === 'club' ? 'Club_name' : 'Workshop_name';
$image_field = $type === 'club' ? 'club_image_URL' : 'Workshop_image_URL';

$title = "Add";
$btn_title = "Save";
$name = "";
$description = "";
$link = "";
$image = "";
$club_leader = "";
$meeting_schedule = "";
$contact = "";
$club_id = "";


/*Update*/

if (isset($_GET['action']) && $_GET['action'] == 'edit') {
  $id = intval($_GET['id']);
  $sql = "SELECT * FROM $table WHERE $id_field = $id";
  $res = mysqli_query($conn, $sql);
  if ($res) {

    $data = $res->fetch_assoc();  //retrive from  Database//
    $name = $data[$name_field];
    $description = $data['description'];
    $link = $data['Registration_link'];
    $image = $data[$image_field];
    if ($type === 'club') {
      $club_leader = $data['club_leader'];
      $meeting_schedule = $data['meeting_schedule'];
      $contact = $data['contact'];
    } else {
      $club_id = $data['Club_ID'];
    }
    $btn_title = "Update";
    $title = "Update";
  }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {
  $name = $_POST['name'];
  $description = $_POST['description'];
  $link = $_POST['registration_link'];
  $image_upload = '';

  if (!empty($_FILES['image']['name'])) {
    $upload_dir = '../images/';
    if (!file_exists($upload_dir)) mkdir($upload_dir, 0777, true);

    $filename = basename($_FILES['image']['name']);
    $target_file = $upload_dir . $filename;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
      $image_upload = '../images/' . $filename;
    }
  }

/*Update if the user updateing */

  if ($_POST['save'] == 'Update' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
  
    if ($type === 'club') {
      $club_leader = $_POST['club_leader'];
      $meeting_schedule = $_POST['meeting_schedule'];
      $contact = $_POST['contact'];
  
      $update_sql = "UPDATE Club SET 
        Club_name = '$name',
        description = '$description',
        Registration_link = '$link',
        club_leader = '$club_leader',
        meeting_schedule = '$meeting_schedule',
        contact = '$contact'";
  
      if ($image_upload) {
        $update_sql .= ", club_image_URL = '$image_upload'";
      }
  
      $update_sql .= " WHERE Club_ID = $id";
    } else {
      $club_id = intval($_POST['club_id']);
      $update_sql = "UPDATE Workshop SET 
        Workshop_name = '$name',
        description = '$description',
        Registration_link = '$link',
        Club_ID = $club_id";
  
      if ($image_upload) {
        $update_sql .= ", Workshop_image_URL = '$image_upload'";
      }
  
      $update_sql .= " WHERE Workshop_ID = $id";
    }
  
    mysqli_query($conn, $update_sql);
  
  } else {
    if ($type === 'club') {
      $club_leader = $_POST['club_leader'];
      $meeting_schedule = $_POST['meeting_schedule'];
      $contact = $_POST['contact'];
  
      $insert_sql = "INSERT INTO Club (Club_name, description, Registration_link, club_leader, meeting_schedule, contact, club_image_URL)
        VALUES ('$name', '$description', '$link', '$club_leader', '$meeting_schedule', '$contact', '$image_upload')";
    } else {
      $club_id = intval($_POST['club_id']);
  
      $insert_sql = "INSERT INTO Workshop (Workshop_name, description, Registration_link, Workshop_image_URL, Club_ID)
        VALUES ('$name', '$description', '$link', '$image_upload', $club_id)";
    }
  
    mysqli_query($conn, $insert_sql);
  }
  

  header("Location: manageClubs.php?type=$type");
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="admin.css">
  <title><?= $title ?> <?= ucfirst($type) ?></title>
  <style> 
  
  /* ========== Back Btn ========== */

  .back-btn {
    width: 100%;
    max-width: 1100px;
    display: flex;
    justify-content: flex-start;
    margin-bottom: 10px;
}

.back-link {
    text-decoration: none;
    color: #243b4a;
    font-weight: bold;
    border: 1px solid #243b4a;
    padding: 8px 14px;
    border-radius: 8px;
    transition: 0.3s;
}

.back-link:hover {
    background-color: #243b4a;
    color: white;
}
</style>
</head>
<body>
<div class="admin-form-page">
  <div class="admin-form-card">
  <div class="back-btn">
      <a href="../Admin/manageClubs.php" class="back-link">← Back</a>
    </div>
    <div class="admin-form-header">
      <h1 class="admin-form-title"><?= $title ?> <?= ucfirst($type) ?></h1>
    </div>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label class="form-label">Name:</label>
        <input type="text" name="name" class="form-control" value="<?= $name ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description:</label>
        <textarea name="description" class="form-control"><?= $description ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Registration Link:</label>
        <input type="text" name="registration_link" class="form-control" value="<?= $link ?>">
      </div>

      <?php if ($type === 'club'): ?>
        <div class="form-group">
          <label class="form-label">Club Leader:</label>
          <input type="text" name="club_leader" class="form-control" value="<?= $club_leader ?>">
        </div>

        <div class="form-group">
          <label class="form-label">Meeting Schedule:</label>
          <input type="text" name="meeting_schedule" class="form-control" value="<?= $meeting_schedule ?>">
        </div>

        <div class="form-group">
          <label class="form-label">Contact:</label>
          <input type="text" name="contact" class="form-control" value="<?= $contact ?>">
        </div>
        <?php else: ?>
        <div class="form-group">
          <label class="form-label">Associated Club:</label>
          <select name="club_id" class="form-control" required>
            <option value="">Select a Club</option>
            <?php
              $clubs_query = "SELECT Club_ID, Club_name FROM Club ORDER BY Club_name";
              $clubs_result = mysqli_query($conn, $clubs_query);
              while ($club = mysqli_fetch_assoc($clubs_result)) {
                $selected = $club['Club_ID'] == $club_id ? 'selected' : '';
                echo "<option value='{$club['Club_ID']}' {$selected}>{$club['Club_name']}</option>";
              }
            ?>
          </select>
        </div>
      <?php endif; ?>
      <div class="form-group">
        <label class="form-label">Image:</label>
        <input type="file" name="image" class="form-control">
        <?php if (!empty($image)): ?>
          <div class="preview-image">
            <img src="<?= $image ?>" alt="Current <?= $type ?> image" style="width: 200px; margin-top: 10px;">
          </div>
        <?php endif; ?>
      </div>
      <?php if (isset($_GET['id'])): ?>
        <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
      <?php endif; ?>
      <input type="hidden" name="save" value="<?= $btn_title ?>">
      <button type="submit" class="submit-btn"><?= $btn_title ?></button>
    </form>
  </div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
<script>feather.replace();</script>
</body>
</html>
