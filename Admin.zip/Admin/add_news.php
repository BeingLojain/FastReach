<?php
require '../include/db_connect.php';
session_start();

$admin_username = $_SESSION['admin_username'];

$adminQuery = $conn->prepare("SELECT Admin_ID FROM Admin WHERE A_Username = ?");
$adminQuery->bind_param("s", $admin_username);
$adminQuery->execute();
$result = $adminQuery->get_result();
$admin = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $link = $_POST['news_link'];

    $targetDir = "../images/news/";
    $fileName = basename($_FILES["image_file"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $imageFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'jpeg', 'png'];

    if (in_array($imageFileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["image_file"]["tmp_name"], $targetFilePath)) {
            $image_url = $targetFilePath;

            $stmt = $conn->prepare("INSERT INTO News (News_Title, News_image_url, news_link, Admin_ID) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssi", $title, $image_url, $link, $admin['Admin_ID']);

            if ($stmt->execute()) {
                $message = "News posted successfully!";
                $msgClass = "success";
            } else {
                $message = "Failed to insert into database.";
                $msgClass = "error";
            }
        } else {
            $message = "Failed to upload image.";
            $msgClass = "error";
        }
    } else {
        $message = "Only JPG, JPEG, and PNG files are allowed.";
        $msgClass = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Post News | Admin</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: "Times New Roman", serif;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .container {
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(10px);
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      max-width: 600px;
      width: 90%;
      border: 2px solid #A9BCC8;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
      font-size: 28px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    label {
      font-weight: bold;
      color: #1F2A34;
      font-size: 17px;
    }

    input[type="text"],
    input[type="url"],
    input[type="file"] {
      padding: 12px;
      border: 1px solid #A9BCC8;
      border-radius: 10px;
      background: #f4f9fc;
      font-size: 16px;
      font-family: "Times New Roman", serif;
    }

    input[type="text"]:focus,
    input[type="url"]:focus,
    input[type="file"]:focus {
      outline: none;
      border-color: #3E4C59;
      background-color: #ffffff;
    }

    button {
      background-color: #243b4a;
      color: white;
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-weight: bold;
      font-family: "Times New Roman", serif;
      transition: 0.3s ease-in-out;
    }

    button:hover {
      background-color: #6B8494;
    }

    .message {
      text-align: center;
      font-weight: bold;
      margin-top: 15px;
    }

    .success {
      color: #1F2A34;
    }

    .error {
      color: #B00020;
    }

    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }

  </style>
</head>
<body>

<div class="container">
<div class="back-btn">
      <a href="../Admin/news_dashboard.php">← Back</a>
</div>
  <h2>Post News</h2>

  <form method="POST" enctype="multipart/form-data">
    <label for="title">News Title:</label>
    <input type="text" id="title" name="title" required>

    <label for="image_file">Upload Image:</label>
    <input type="file" id="image_file" name="image_file" accept="image/*" required>

    <label for="news_link">News Link:</label>
    <input type="url" id="news_link" name="news_link" required>

    <button type="submit">Publish News</button>

    <?php if (isset($message)) echo "<div class='message $msgClass'>$message</div>"; ?>
  </form>

  </div>


</body>
</html>
