
<?php
require '../include/db_connect.php';

session_start();

if (isset($_SESSION['admin_username'])) {
    $admin_username = $_SESSION['admin_username'];

    $admin_username = $conn->real_escape_string($admin_username);

    $sql = "SELECT * FROM admin WHERE A_Username = '$admin_username'"; 
    
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc(); 
    } else {
        echo "No admin records found.";
        exit();
    }
} else {
    header('Location: ../home/login.php');
    exit();
}

//<----------------------------------- Book--------------------------------->
$total_book = $conn->query("SELECT COUNT(*) AS count FROM Book")->fetch_assoc()['count'];
$pending_book= $conn->query("SELECT COUNT(*) AS count FROM Book WHERE is_approved IS NULL")->fetch_assoc()['count'];
$approved_book=$conn->query("SELECT COUNT(*) AS count FROM Book WHERE is_approved = 1")->fetch_assoc()['count'];
$rejected_book=$conn->query("SELECT COUNT(*) AS count FROM Book WHERE is_approved = 0")->fetch_assoc()['count'];
//<----------------------------------- Book--------------------------------->
$total_note= $conn->query("SELECT COUNT(*) AS count FROM Note")->fetch_assoc()['count'];
$pending_note= $conn->query("SELECT COUNT(*) AS count FROM Note WHERE is_approved IS NULL")->fetch_assoc()['count'];
$approved_note=$conn->query("SELECT COUNT(*) AS count FROM Note WHERE is_approved = 1")->fetch_assoc()['count'];
$rejected_note=$conn->query("SELECT COUNT(*) AS count FROM Note WHERE is_approved = 0")->fetch_assoc()['count'];

//<----------------------------------- Student--------------------------------->
$total_Student = $conn->query("SELECT COUNT(*) AS count FROM Student")->fetch_assoc()['count'];
$total_male = $conn->query("SELECT COUNT(*) AS count FROM Student WHERE S_Gender = 'Male'")->fetch_assoc()['count'];
$total_female = $conn->query("SELECT COUNT(*) AS count FROM Student WHERE S_Gender = 'Female'")->fetch_assoc()['count'];

//<----------------------------------- news --------------------------------->
$total_news = $conn->query("SELECT COUNT(*) AS count FROM News")->fetch_assoc()['count'];

// <------------------------------ Lockers ------------------------------------>
$total_locker = $conn->query("SELECT COUNT(*) AS count FROM Locker")->fetch_assoc()['count'];
$booked_locker = $conn->query("SELECT COUNT(*) AS count FROM Locker WHERE locker_status = 'Rented'")->fetch_assoc()['count'];
$available_locker = $conn->query("SELECT COUNT(*) AS count FROM Locker WHERE locker_status = 'Available'")->fetch_assoc()['count'];

// <-------------------------- Clubs & Workshops ------------------------------>
$total_club = $conn->query("SELECT COUNT(*) AS count FROM Club")->fetch_assoc()['count'];
$total_workshop = $conn->query("SELECT COUNT(*) AS count FROM Workshop")->fetch_assoc()['count'];

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <title>Admin Dashboard</title>

  <header>
        <!-- Navbar ------------------------------------------------------------------->
        <nav class="navbar" id="navbar">
            <div class="logo">
                <img src="../images/uni-logo.png" alt="Collage Logo">
                <a href="../home/home.html">FastReach</a>
            </div>
            <ul class="nav-links" id="nav-links">
                <li><a href="#admin_dashboard.php" class="active">Home</a></li>
                <li><a href="../Books/adminAproveB.php">Approve Books</a></li>               
                <li><a href="../Books/adminAproveN.php">Approve Notes</a></li>
                <li><a href="manageClubs.php">Manage Clubs & Workshops</a></li>
                <li><a href="AdminLockers.php">Manage Lockers</a></li>
                <li><a href="news_dashboard.php">Manage News</a></li>
                <li><a href="Admin_Mange_Student.php">Manage Students</a></li>

            </ul>

            <div class="user-login-container">
                    <a href="adminProfile.php"><div class="user-icon"></div></a>
                    <a href="../home/logout.php" class="login-btn">Log Out</a>
            </div>

            <div class="hamburger" id="hamburger">
                <i class="fas fa-bars"></i>
            </div>
        </nav>
    </header>

  <style>
    /*------------------------------------------------Navbar css-------------------------------------------------*/

    body{
        margin: 0;
    }
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px 40px;
        background: hsla(0, 0%, 100%, 0.495);
        box-shadow: 2px 2px 10px #555;
        position: fixed;
        width: calc(100% - 80px);
        top: 0;
        left: 0;
        transition: background 0.3s ease;
        z-index: 1000;
        font-family: "Times New Roman", Arial, sans-serif;
    }

    .hamburger {
        display: none;
        font-size: 24px;
        cursor: pointer;
    }

    .navbar.scrolled {
        background: white; 
    }
    .logo {
        display: flex;
        align-items: center;
    }
    .logo img {
        height: 40px;
        margin-right: 10px;
    }
    .logo a {
        text-decoration: none;
        color: #243b4a;
        font-size: 27px;
        font-weight: bold;
    }
    .logo a:hover {
        color: #6B5A69;
    }
    .nav-links {
        list-style: none;
        display: flex;
        gap: 20px;
        margin: 0;
        padding: 0;
    }
    .nav-links li {
        position: relative;
    }
    .nav-links a {
        text-decoration: none;
        color: #555;
        font-weight: bold;
        padding: 10px;
        display: block;
    }
    .nav-links a:hover, .nav-links .active {
        color: black;
        border-bottom: 3px solid #243b4a;
    }

    .nav-links.show {
        display: block;
    }


    @media (max-width: 768px) {
        .nav-links {
            display: none;
            flex-direction: column;
            background: white;
            position: absolute;
            top: 60px;
            right: 0;
            width: 250px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
            font-family: "Times New Roman", Arial, sans-serif;
        }
        
        .nav-links.show {
            display: flex;
        }

        .hamburger {
            display: block;
        }
    }
    .login-btn {
        background: #243b4a;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 20px;
        cursor: pointer;
        text-decoration: none;
        font-weight: bold;
    }
    .login-btn:hover {
        background: #6B5A69;
    }

    .user-icon {
      width: 35px;
      height: 35px;
      background-image: url('../images/userB.png');
      background-size: cover;
      transition: background-image 0.3s ease;
    }

    .user-icon:hover {
      background-image: url('../images/userP.png');
    }

    .user-login-container {
            display: flex;
            align-items: center;
            gap: 10px; 
        }
   /*------------------------------------------------------body css----------------------------------------------------------*/

    body {
      font-family: "Times New Roman", Arial, sans-serif;
      background: #f4f4f4;
      margin: 0;
      padding: 40px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    h1 {
      color: #444;
      margin-bottom: 30px;
      border-bottom: 2px solid #ddd;
    }
    h2 {
      font-size: 22px;
      margin: 30px 0 10px;
      color: #243b4a;
      text-align: left;
      width: 100%;
      max-width: 900px;
      border-bottom: 2px solid #ddd;
      padding-bottom: 5px;
    }
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
      width: 100%;
      max-width: 900px;
    }
    .card {
      background-color: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-align: center;
    }
    .card h3 {
      margin: 0;
      color: #243b4a;
    }
    .card p {
      font-size: 22px;
      margin-top: 10px;
      color: #333;
      font-weight: bold;
    }
  
  </style>
</head>
<!-- ------------------------------body----------------------------- -->
<body>
<br><br>
<br><br>
  <h1>Admin Dashboard</h1>
 
<!--  Book Statistics -->
<h2> Book Statistics</h2>
<div class="stats">
  <div class="card"><h3>Total Books</h3><p><?= $total_book ?></p></div>
  <div class="card"><h3>Pending Books</h3><p><?= $pending_book ?></p></div>
  <div class="card"><h3>Approved Books</h3><p><?= $approved_book ?></p></div>
  <div class="card"><h3>Rejected Books</h3><p><?= $rejected_book ?></p></div>
</div>

<!-- Note Statistics -->
<h2> Note Statistics</h2>
<div class="stats">
  <div class="card"><h3>Total Notes</h3><p><?= $total_note ?></p></div>
  <div class="card"><h3>Pending Notes</h3><p><?= $pending_note ?></p></div>
  <div class="card"><h3>Approved Notes</h3><p><?= $approved_note ?></p></div>
  <div class="card"><h3>Rejected Notes</h3><p><?= $rejected_note ?></p></div>
</div>

<!-- Locker Statistics -->
<h2> Locker Statistics</h2>
<div class="stats">
  <div class="card"><h3>Total Lockers</h3><p><?= $total_locker ?></p></div>
  <div class="card"><h3>Available Lockers</h3><p><?= $available_locker ?></p></div>
  <div class="card"><h3>Rented Lockers</h3><p><?= $booked_locker ?></p></div>
</div>

<!--  Student Statistics -->
<h2> Student Statistics</h2>
<div class="stats">
  <div class="card"><h3>Total Students</h3><p><?= $total_Student ?></p></div>
  <div class="card"><h3>Male Students</h3><p><?= $total_male ?></p></div>
  <div class="card"><h3>Female Students</h3><p><?= $total_female ?></p></div>
</div>

<!-- Club & Workshop Statistics -->
<h2> Club & Workshop Statistics</h2>
<div class="stats">
  <div class="card"><h3>Total Clubs</h3><p><?= $total_club ?></p></div>
  <div class="card"><h3>Total Workshops</h3><p><?= $total_workshop ?></p></div>
</div>



<!--  News Statistics -->
<h2> News Statistics</h2>
<div class="stats">
  <div class="card"><h3>Total News Posts</h3><p><?= $total_news ?></p></div>
</div>


<!-- header navbar scripts -->

<script>
        window.addEventListener("scroll", function () {
            let navbar = document.getElementById("navbar");
            if (window.scrollY > 50) {
                navbar.classList.add("scrolled");
            } else {
                navbar.classList.remove("scrolled");
            }
        });
    </script>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const hamburger = document.getElementById("hamburger");
        const navLinks = document.getElementById("nav-links");
        const servicesToggle = document.getElementById("services-toggle");
        const servicesMenu = document.getElementById("services-menu");

        hamburger.addEventListener("click", function () {
            navLinks.classList.toggle("show");
        });

        servicesToggle.addEventListener("click", function (e) {
            e.preventDefault();
            servicesMenu.classList.toggle("show");
        });
    });
</script>

<script>
    document.getElementById("about-trigger").addEventListener("click", function(event) {
    event.preventDefault();
    document.getElementById("about-overlay").classList.add("active");
    document.body.style.overflow = "hidden";
});
document.getElementById("close-about").addEventListener("click", function() {
    document.getElementById("about-overlay").classList.remove("active");
    document.body.style.overflow = ""; 
});

</script>
  
</body>
</html>
