<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require '../include/db_connect.php';

$adminId = $_SESSION['Admin_ID'];

if (!isset($_SESSION['Admin_ID'])) {
  echo "<script>alert('Unauthorized access. Please log in as admin.'); window.location.href = '../home/login.php';</script>";
  exit();
}

$student = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['select_student'])) {
        $selected_id = $_POST['selected_id'];
        $res = $conn->query("SELECT * FROM Student WHERE Student_ID = $selected_id");
        if ($res && $res->num_rows > 0) {
            $student = $res->fetch_assoc();
        }
    } elseif (isset($_POST['update_student'])) {
        $stmt = $conn->prepare("UPDATE Student SET S_Fname=?, S_Lname=?, S_Email=?, S_Major=?, S_Gender=?, S_Password=?, S_PhoneNumber=?, S_Collage=?, S_BankAccount=?, Street_Name=?, City=?, Postal_Code=?, Admin_ID=? WHERE Student_ID=?");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("ssssssssssssii",
            $_POST['S_Fname'], $_POST['S_Lname'], $_POST['S_Email'], $_POST['S_Major'], $_POST['S_Gender'], $_POST['S_Password'],
            $_POST['S_PhoneNumber'], $_POST['S_Collage'], $_POST['S_BankAccount'], $_POST['Street_Name'], $_POST['City'], $_POST['Postal_Code'],
            $adminId, $_POST['Student_ID']
        );
        $stmt->execute();

        if ($stmt->error) {
            die("Execute failed: " . $stmt->error);
        }

        header("Location: ../Admin/Admin_Mange_Student.php");
        exit();
    }
}

$students = $conn->query("SELECT Student_ID, S_Fname, S_Lname FROM Student");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Student</title>
  <style>
    body {
      font-family: 'Times New Roman', sans-serif;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 900px;
      margin: 40px auto;
      background: rgba(255, 255, 255, 0.9);
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }
    h1 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }
    form {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 15px;
    }
    label {
      display: flex;
      flex-direction: column;
      font-weight: bold;
      font-size: 14px;
      color: #444;
    }
    input, select {
      padding: 10px;
      margin-top: 5px;
      border-radius: 8px;
      border: 1px solid #aaa;
    }
    button {
      grid-column: span 2;
      margin-top: 20px;
      padding: 12px;
      font-size: 16px;
      background: #243b4a;
      color: white;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-family: 'Times New Roman', sans-serif;
    }
    button:hover {
      background: #162831;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }
  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/Admin_Mange_Student.php">← Back</a>
    </div>
    <h1>Edit Student</h1>

    <form method="POST">
      <label>Select Student:
        <select name="selected_id" onchange="this.form.submit()" required>
          <option value="">Choose a student</option>
          <?php while($s = $students->fetch_assoc()): ?>
            <option value="<?= $s['Student_ID'] ?>" <?= isset($student) && $student['Student_ID'] == $s['Student_ID'] ? 'selected' : '' ?>>
              <?= $s['S_Fname'] . ' ' . $s['S_Lname'] . ' (ID: ' . $s['Student_ID'] . ')' ?>
            </option>
          <?php endwhile; ?>
        </select>
      </label>
      <input type="hidden" name="select_student" value="1">
    </form>

    <?php if ($student): ?>
    <form method="POST" onsubmit="return confirmUpdate();">
      <label>Student ID:
        <input type="text" name="Student_ID" readonly value="<?= $student['Student_ID'] ?>">
      </label>
      <label>First Name:
        <input type="text" name="S_Fname" required value="<?= htmlspecialchars($student['S_Fname']) ?>">
      </label>
      <label>Last Name:
        <input type="text" name="S_Lname" required value="<?= htmlspecialchars($student['S_Lname']) ?>">
      </label>
      <label>Email:
        <input type="email" name="S_Email" required value="<?= htmlspecialchars($student['S_Email']) ?>">
      </label>
      <label>Major:
        <input type="text" name="S_Major" required value="<?= htmlspecialchars($student['S_Major']) ?>">
      </label>
      <label>Gender:
        <select name="S_Gender" required>
          <option value="Male" <?= $student['S_Gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
          <option value="Female" <?= $student['S_Gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
        </select>
      </label>
      <label>Password:
        <input type="text" name="S_Password" required value="<?= htmlspecialchars($student['S_Password']) ?>">
      </label>
      <label>Phone Number:
        <input type="text" name="S_PhoneNumber" required value="<?= htmlspecialchars($student['S_PhoneNumber']) ?>">
      </label>
      <label>Collage:
        <input type="text" name="S_Collage" required value="<?= htmlspecialchars($student['S_Collage']) ?>">
      </label>
      <label>Bank Account:
        <input type="text" name="S_BankAccount" required value="<?= htmlspecialchars($student['S_BankAccount']) ?>">
      </label>
      <label>Street Name:
        <input type="text" name="Street_Name" required value="<?= htmlspecialchars($student['Street_Name']) ?>">
      </label>
      <label>City:
        <input type="text" name="City" required value="<?= htmlspecialchars($student['City']) ?>">
      </label>
      <label>Postal Code:
        <input type="text" name="Postal_Code" required value="<?= htmlspecialchars($student['Postal_Code']) ?>">
      </label>
      <button type="submit" name="update_student">Update Student</button>
    </form>
    <?php endif; ?>
  </div>

  <script>
    function confirmUpdate() {
      return confirm("Are you sure you want to update this student’s information?");
    }
  </script>
</body>
</html>
