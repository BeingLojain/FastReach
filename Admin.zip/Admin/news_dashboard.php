<?php
require '../include/db_connect.php';

$result = $conn->query("SELECT * FROM News");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Manage News</title>
  <style>
    body {
      font-family: 'Times New Roman', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(to bottom right, #D7E2EC, #6B8494, #3E4C59);
      min-height:94.5vh;
    }

    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 30px;
      background: rgba(255, 255, 255, 0.75);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
      border-radius: 20px;
      backdrop-filter: blur(12px);
    }

    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 40px;
    }

    .actions {
      text-align: center;
      margin-bottom: 30px;
    }

    .btn {
      display: inline-block;
      margin: 10px;
      padding: 12px 24px;
      background-color: #243b4a;
      color: white;
      border: none;
      border-radius: 12px;
      text-decoration: none;
      font-size: 16px;
      transition: background 0.3s ease;
    }

    .btn:hover {
      background-color: #6B8494;
    }

    .news-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 20px;
    }

    .news-card {
      background: white;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
      transition: transform 0.2s;
    }

    .news-card:hover {
      transform: translateY(-5px);
    }

    .news-card img {
      width: 100%;
      height: 160px;
      object-fit: cover;
      border-bottom: 1px solid #ddd;
    }

    .news-card-content {
      padding: 15px;
    }

    .news-card-content h3 {
      font-size: 18px;
      margin: 0 0 10px;
      color: #222;
    }

    .news-card-content a {
      text-decoration: none;
      color: #243b4a;
      font-size: 14px;
    }

    .news-card-content a:hover {
      text-decoration: underline;
    }
    .back-btn {
      margin-bottom: 20px;
    }

    .back-btn a {
      text-decoration: none;
      color: #243b4a;
      font-weight: bold;
      border: 1px solid #243b4a;
      padding: 8px 14px;
      border-radius: 8px;
    }

    .back-btn a:hover {
      background-color: #243b4a;
      color: white;
    }

  </style>
</head>
<body>
  <div class="container">
  <div class="back-btn">
      <a href="../Admin/admin_dashboard.php">← Back</a>
    </div>
    <h1>Manage News</h1>

    <div class="actions">
      <a href="add_news.php" class="btn">Add News</a>
      <a href="edit_news.php" class="btn">Edit News</a>
      <a href="delete_news.php" class="btn">Delete News</a>
    </div>

    <div class="news-grid">
      <?php while($row = $result->fetch_assoc()): ?>
        <div class="news-card">
          <img src="<?= htmlspecialchars($row['News_image_url']) ?>" alt="News Image">
          <div class="news-card-content">
            <h3><?= htmlspecialchars($row['News_Title']) ?></h3>
            <a href="<?= htmlspecialchars($row['news_link']) ?>" target="_blank">Link↗</a>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</body>
</html>
