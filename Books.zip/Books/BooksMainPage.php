<?php
//session starting and prven not loged in student and redirct them to log in page
session_start();


if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}

include '../include/header.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Books and Notes Main page</title>
    <link rel="stylesheet" href="Style-for-mainpage-Forms.css" />
  </head>
  <body>
   
      <!-------------------------- ChatBoot دليلك and Back to top Button------------------------------>
      <?php include '../include/shared_buttons.html';?>

     <!-----------------------------SECTION 1 (Background section )----------------------------------->
    <div class="Book_Shelve_background">
      <h1>Buy and Sell Used Books & Notes</h1>
      <br /><br />
      <p>
        This student platform allows you to easily buy and sell used books and
        notes within your college community. Connect with fellow students, save
        money, and get the materials you need for your classes, all in one
        place.
      </p>
      <br />
    </div>

    <!------------------------------SECTiON 2 (card Section)----------------------------------------->
    <div class=Sec2-ContainerText> 
    <h1>  <span style="color: #dcd0ca;">FOR </span> STUDENTS,<span style="color: #dcd0ca;;"> BY </span>STUDENTS </h1>  
  </div>
    <div class="Sec2-container">
      <div
        data-text="Explore"
        style="--r: -15; font-weight: bold; font-size: 20px"
        class="glass"
      >
        <img src="../images/Bookicon.png" alt="Book Icon" class="icon" />
        <p>
          Your Books 
        </p>
      </div>
      <div
        data-text="Buy"
        style="--r: 5; font-weight: bold; font-size: 20px"
        class="glass"
      >
        <img src="../images/Sellicon.png" alt="Notes Icon" class="icon" />
        <p>
          Your Notes
        </p>
      </div>
      <div
        data-text="Sell"
        style="--r: 25; font-weight: bold; font-size: 20px"
        class="glass"
      >
        <img src="../images/Buyicon.png" alt="Book Icon" class="icon" />
        <p>
          Your Marketplace
        </p>
      </div>
    </div> 

    <hr style="font-weight: bolder" />

    <!------------------------------SECTION 3 ( services section) ----------------------------------------->
    <div class="service-section">
      <h2> Services</h2>
      <h1>What can you do here</h1>
    
      <div class="service-buttons-container">
        <button class="service-button" onclick="location.href='AddBookForm.html';">
          <img src="../images/AddBook.jpeg" alt="Book Icon">
          <span>Add Your Book to Share or Sale</span>
        </button>
    
        <button class="service-button">
          <img src="../images/bookincart.png" alt="Explore All Types of Books" onclick="location.href='Brawse Page.php';">
          <span>Explore All Types of Books</span>
        </button>
    
        <button class="service-button">
          <img src="../images/exchangenotes.jpeg" alt="Explore Your Colleague's Notes" onclick="location.href='Brows Note page.php';">
          <span>Explore Your Colleague's Notes</span>
        </button>
    
        <button class="service-button" onclick="location.href='AddNotesForm.html';">
          <img src="../images/AddNote.jpeg" alt="Add Your Notes to Share or Sale">
          <span>Add Your Notes to Share or Sale</span>
        </button>
      </div>
    </div>

    
    <?php include '../include/footer.html'; ?>   
  </body>
</html>
