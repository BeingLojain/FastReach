<?php
// session start and require the student login, if it is not logged in it will be redirected to login page
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}

//doing note removal
if (($_POST['source'] ?? '') === 'note' && isset($_POST['id'])) {
    $noteId = intval($_POST['id']);
    if (isset($_SESSION['cart_notes'])) {
        $_SESSION['cart_notes'] = array_filter($_SESSION['cart_notes'], fn($id) => $id != $noteId);
    }
    header("Location: ../cart/cart.php");
    exit();
}

//doing book removal
if (isset($_POST['book_id'])) {
    $bookId = intval($_POST['book_id']);
    if (isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array_filter($_SESSION['cart'], fn($id) => $id != $bookId);
    }
    header("Location: ../cart/cart.php");
    exit();
}

//if no valid request id made the student will be redirected
header("Location: ../cart/cart.php");
exit();