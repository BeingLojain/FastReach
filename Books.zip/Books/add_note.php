<?php
//require login if the student not logged in, it will be redircted to the home page
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: ../home/login.php");
    exit();
}

require '../include/db_connect.php';
//the student who adds the note into the system
$added_by = $_SESSION['student_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $title = $_POST['title'] ?? '';
    $major = $_POST['major'] ?? '';
    $description = $_POST['description'] ?? '';
    $price_option = $_POST['price_option'] ?? 'free';
    $price = ($price_option === 'free') ? 0.00 : floatval($_POST['price'] ?? 0.00);
//deal with file upload
    $image_url = '';
    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        $target_dir = 'uploads/';
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $file_name = basename($_FILES['file']['name']);
        $target_file = $target_dir . time() . "_" . $file_name;
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
            $image_url = $target_file;
        }
    }
 //insert the information into DB
    $sql = "INSERT INTO Note (Note_Title, Note_description, Note_major, Note_image_URL, N_price, added_by, Admin_ID, is_approved) 
            VALUES (?, ?, ?, ?, ?, ?, NULL, NULL)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssssdi", $title, $description, $major, $image_url, $price, $added_by);
        if ($stmt->execute()) {
        //after submiting the form the student will be redircted to the Books main page
            header("Location: ../Books/BooksMainPage.php");
            exit();
        } else {
            echo "Database Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
} else {
    header("Location: AddNotesForm.html");
    exit();
}
?>