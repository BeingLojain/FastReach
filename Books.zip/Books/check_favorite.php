<?php
// session start and require the student login, if it is not logged in it will be redirected to login page
session_start();
if (!isset($_SESSION['student_id'])) {
    http_response_code(403); 
    echo 'unauthorized';
    exit();
}

include '../include/db_connect.php';

$studentId = $_SESSION['student_id']; 
$type = $_GET['type'] ?? '';
$id = intval($_GET['id'] ?? 0);


if (!$type || !$id) {
    echo 'invalid';
    exit();
}

$table = '';
$column = '';

// selecting the table & column based on type(Book or not)
if ($type === 'book') {
    $table = 'FavoritesBook';
    $column = 'Book_ID';
} elseif ($type === 'note') {
    $table = 'FavoritesNote';
    $column = 'Note_ID';
} else {
    echo 'invalid_type';
    exit();
}

// Check if the Student already likes this book or not
$stmt = $conn->prepare("SELECT 1 FROM $table WHERE Student_ID = ? AND $column = ?");
$stmt->bind_param("ii", $studentId, $id);
$stmt->execute();
$stmt->store_result();

echo ($stmt->num_rows > 0) ? 'yes' : 'no';

$stmt->close();
$conn->close();
?>