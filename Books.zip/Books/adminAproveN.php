<?php
session_start();
//checking the admin login, if its not logged in rederict to log in page
if (!isset($_SESSION['admin_username']) || !isset($_SESSION['Admin_ID'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: ../home/login.php");
    exit();
}

require '../include/db_connect.php';
//storing the admin id from the session
$admin_id = $_SESSION['Admin_ID']; 

/// Deal with approval or rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_id'])) {
    $note_id = $_POST['note_id'];

    if (isset($_POST['approve'])) {
        $stmt = $conn->prepare("UPDATE Note SET is_approved = 1, Admin_ID = ? WHERE Note_ID = ?");
        $stmt->bind_param("ii", $admin_id, $note_id);
        $stmt->execute();
    } elseif (isset($_POST['reject'])) {
        $stmt = $conn->prepare("UPDATE Note SET is_approved = 0, Admin_ID = ? WHERE Note_ID = ?");
        $stmt->bind_param("ii", $admin_id, $note_id);
        $stmt->execute();
    }
}
// Get pending Notes ( is approved Null )
$result = $conn->query("SELECT * FROM Note WHERE is_approved IS NULL");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Approve Notes</title>
    <style>
    body {
        font-family: "Times New Roman", Arial, sans-serif;
        background: linear-gradient(to bottom, #d7e2ec, #a7bac8, #6b8494);
        margin: 0;
        padding: 40px;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 100vh;
    }

    h1 {
        color: #333;
        margin-bottom: 30px;
    }

    .grid-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 30px;
        width: 100%;
        max-width: 1100px;
    }

    .note-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        min-height: 540px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .note-card-content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }

    .description-block {
        min-height: 60px;
    }

    .image-wrapper {
        flex-grow: 1;
        display: flex;
        align-items: flex-end;
        margin-top: 10px;
    }

    .image-wrapper img {
        max-height: 160px;
        object-fit: contain;
        width: 100%;
        background-color: #f4f4f4;
        border-radius: 8px;
        padding: 8px;
    }

    .actions {
        display: flex;
        justify-content: space-between;
        margin-top: 16px;
    }

    button {
        padding: 10px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        font-family: 'Times New Roman', sans-serif;
    }

    .approve {
        background-color: #4CAF50;
        color: white;
    }

    .reject {
        background-color: #f44336;
        color: white;
    }

    h2 {
        margin: 5px 0 10px;
        font-size: 20px;
        color: #333;
    }

    p {
        font-size: 14px;
        margin: 6px 0;
        color: #555;
    }

    .no-notes {
        background: rgba(255, 255, 255, 0.95);
        padding: 25px 40px;
        border-radius: 12px;
        font-size: 18px;
        color: #333;
        font-weight: bold;
        text-align: center;
        margin-top: 80px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
    }
    .back-btn {
        width: 100%;
        max-width: 1100px;
        display: flex;
        justify-content: flex-start;
        margin-bottom: 10px;
    }

    .back-link {
        text-decoration: none;
        color: #243b4a;
        font-weight: bold;
        border: 1px solid #243b4a;
        padding: 8px 14px;
        border-radius: 8px;
        transition: 0.3s;
    }

    .back-link:hover {
        background-color: #243b4a;
        color: white;
    }
    </style>
</head>
<body>
    <div class="back-btn">
      <a href="../Admin/admin_dashboard.php" class="back-link">← Back</a>
    </div>

<h1>Pending Note Approvals</h1>
<!--------if Notes are founds will loop through each Notes and show its info the student enter ----->
<?php if ($result->num_rows > 0): ?>
    <div class="grid-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="note-card">
                <div class="note-card-content">
                    <h2><?= htmlspecialchars($row['Note_Title']) ?></h2>
                    <p><strong>Major:</strong> <?= htmlspecialchars($row['Note_major']) ?></p>
                    <p><strong>Price:</strong> <?= $row['N_price'] == 0 ? 'Free' : number_format($row['N_price'], 2) . ' SAR' ?></p>
                    <p><strong>Student ID:</strong> <?= htmlspecialchars($row['added_by']) ?></p>
                    <div class="description-block">
                        <p><strong>Description:</strong><br><?= nl2br(htmlspecialchars($row['Note_description'])) ?></p>
                    </div>

                    <?php if (!empty($row['Note_image_URL'])): ?>
                        <div class="image-wrapper">
                            <img src="<?= htmlspecialchars($row['Note_image_URL']) ?>" alt="Note Preview">
                        </div>
                    <?php endif; ?>
                </div>
                
<!--------form buttons approve or reject  ----->
                <form method="POST" class="actions">
                    <input type="hidden" name="note_id" value="<?= $row['Note_ID'] ?>">
                    <button type="submit" name="approve" class="approve">Approve</button>
                    <button type="submit" name="reject" class="reject" onclick="return confirm('Are you sure you want to reject this note?');">Reject</button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>
<?php else: ?>
    <div class="no-notes">No pending books Need to be approved</div>
<?php endif; ?>

<?php $conn->close(); ?>
</body>
</html>