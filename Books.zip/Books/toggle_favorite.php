<?php

session_start();
header('Content-Type: text/plain');
//this part prevent not logged in student 
if (!isset($_SESSION['student_id'])) {
    http_response_code(403);
    echo 'unauthorized';
    exit();
}

include '../include/db_connect.php';

$studentId = $_SESSION['student_id'];
$type = $_POST['type'] ?? '';
$id = intval($_POST['id'] ?? 0);

if (!$type || !$id) {
    http_response_code(400);
    echo 'invalid';
    exit();
}

$table = '';
$column = '';

//selecting the table & column based on type(Book or not)
if ($type === 'book') {
    $table = 'FavoritesBook';
    $column = 'Book_ID';
} elseif ($type === 'note') {
    $table = 'FavoritesNote';
    $column = 'Note_ID';
} else {
    http_response_code(400);
    echo 'invalid_type';
    exit();
}

$checkStmt = $conn->prepare("SELECT 1 FROM $table WHERE Student_ID = ? AND $column = ?");
$checkStmt->bind_param("ii", $studentId, $id);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
//it is favorite so remove it (delete)
    $removeStmt = $conn->prepare("DELETE FROM $table WHERE Student_ID = ? AND $column = ?");
    $removeStmt->bind_param("ii", $studentId, $id);
    $removeStmt->execute();
    echo 'removed';
    $removeStmt->close();
} else {
//it is not favorite so add it(insert)
    $addStmt = $conn->prepare("INSERT INTO $table (Student_ID, $column) VALUES (?, ?)");
    $addStmt->bind_param("ii", $studentId, $id);
    $addStmt->execute();
    echo 'added';
    $addStmt->close();
}

$checkStmt->close();
$conn->close();
?>