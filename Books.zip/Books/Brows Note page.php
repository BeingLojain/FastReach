<?php

session_start();
include '../include/header.php';

if (!isset($_SESSION['student_id'])) {
   header("Location: ../home/login.php");
   exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_id']) && isset($_POST['track_explore'])) {
   

    include '../include/db_connect.php';
    $student_id = $_SESSION['student_id'];
    $note_id = intval($_POST['note_id']);

    $sql = "INSERT IGNORE INTO Student_Explore_Note (Note_ID, Student_ID) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $note_id, $student_id);
    $stmt->execute();
    $stmt->close();

    echo "success";
    exit;
}


$page_title = "Explore All Type of Notes";
?>

<?php
//full error display for debugging the page
error_reporting(E_ALL);
ini_set('display_errors', 1);
include '../include/db_connect.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no">
    <link rel="stylesheet" href="Style-for-BrowsBook-Note.css">
    <title>Explore All Type of Notes</title>
</head>
<body>
<!-------------------------- ChatBoot دليلك and Back to top Button------------------------------>
<?php include '../include/shared_buttons.html';?>
<!-- ---------------------------- Browse Note Page ---------------------------- -->
<?php
//retrieve filters from URL params
$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? '';
$major = $_GET['major'] ?? '';
$sort = $_GET['sort'] ?? '';

//this is the Note that will shows in this page 
$sql = "SELECT * FROM Note WHERE is_approved = 1";

//accsept search by Note title or its description
if (!empty($search)) {
    $searchEscaped = $conn->real_escape_string($search);
    $sql .= " AND (Note_Title LIKE '%$searchEscaped%' OR Note_description LIKE '%$searchEscaped%')";
}

//filter debend on type
if ($type === 'buy') {
    $sql .= " AND N_price > 0";
} elseif ($type === 'free') {
    $sql .= " AND N_price = 0";
}
//filter debend major
if (!empty($major)) {
    $majorEscaped = $conn->real_escape_string($major);
    $sql .= " AND Note_major = '$majorEscaped'";
}
//the sorting result
switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY N_price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY N_price DESC";
        break;
    case 'newest':
        $sql .= " ORDER BY Note_ID DESC";
        break;
    case 'title':
        $sql .= " ORDER BY Note_Title ASC";
        break;
    default:
        $sql .= " ORDER BY Note_ID DESC";
}
$result = $conn->query($sql);
?>

<!------------- filters and search Section --------->
<form method="GET">
    <div class="background-container">
        <div class="search_countener">
        <!------------- filters based on three buttons (boks for sale-for free- All)  --------->
            <div class="search_button1">
                <button type="submit" name="type" value="" class="button_search">All</button></div>
            <div class="search_button2">
                <button type="submit" name="type" value="buy" class="button_search">Buy</button>
            </div>
            <div class="search_button2">
                <button type="submit" name="type" value="free" class="button_search">Free</button>
            </div>
            <!---------- search entering --------->
            <div class="search_button3">
                <div class="group">
                    <svg class="icon" viewBox="0 0 24 24"><path d="..."/></svg>
                    <input name="search" placeholder="Search" type="search" class="input" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                </div>
            </div>
             <!----- filter based on the major ----->
            <div>
                <select id="major" name="major" onchange="this.form.submit()">
                    <option value="">All Majors</option>
                    <option value="Computer Science" <?= ($_GET['major'] ?? '') == 'Computer Science' ? 'selected' : '' ?>>Computer Science</option>
                    <option value="Physics" <?= ($_GET['major'] ?? '') == 'Physics' ? 'selected' : '' ?>>Physics</option>
                    <option value="Mathematics" <?= ($_GET['major'] ?? '') == 'Mathematics' ? 'selected' : '' ?>>Mathematics</option>
                    <option value="English" <?= ($_GET['major'] ?? '') == 'English' ? 'selected' : '' ?>>English</option>
                    <option value="Kindergarten" <?= ($_GET['major'] ?? '') == 'Kindergarten' ? 'selected' : '' ?>>Kindergarten</option>
                    <option value="Sport and Exercise Sciences" <?= ($_GET['major'] ?? '') == 'Sport and Exercise Sciences' ? 'selected' : '' ?>>Sport and Exercise Sciences</option>
                </select>
            </div>
            <div>
                 <!----- sort based on the (price(hight or low )-Title- Newest) ----->
                <select name="sort" id="sort" onchange="this.form.submit()">
                    <option value="">Sort by</option>
                    <option value="price_asc" <?= ($_GET['sort'] ?? '') == 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
                    <option value="price_desc" <?= ($_GET['sort'] ?? '') == 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                    <option value="newest" <?= ($_GET['sort'] ?? '') == 'newest' ? 'selected' : '' ?>>Newest</option>
                    <option value="title" <?= ($_GET['sort'] ?? '') == 'title' ? 'selected' : '' ?>>Title A-Z</option>
                </select>
            </div>
        </div>
    </div>
</form>
<br><br><br>

<h2 class="brows-Book-note-heading">View all Notes</h2>
<div class="books-container">
<?php
//Display Notes 
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $title = htmlspecialchars($row['Note_Title']);
        $desc = htmlspecialchars($row['Note_description']);
        $price = htmlspecialchars($row['N_price']);
        $img = htmlspecialchars($row['Note_image_URL']);
        $noteId = $row['Note_ID'];

         //change them to javaScript safe strings to enable pop up window
         $titleJS = json_encode($title);
         $descJS = json_encode($desc);
         $imgJS = json_encode($img);
         $priceJS = json_encode($price);
        echo "
<div class='book-card' onclick='openNoteModal($noteId, $titleJS, $descJS, $imgJS, $priceJS)'>    <img src='$img' alt='$title' class='book-image'>
    <div class='book-info'>
        <h3>$title</h3>
        <p class='description'>$desc</p>
    </div>
    <hr class='card-divider'>
    <div class='card-footer'>
        <div class='card-Riyal'>
            <img src='../images/Saudi Riyal (1).png' alt='ريال'>
            <span class='card-price'>$price</span>
        </div>
        <button onclick=\"event.stopPropagation(); addToCartNote($noteId);\" class='card-btn' title='Add to Cart'>
            <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><path d='m397.78 316h-205.13a15 15 0 0 1 -14.65-11.67l-34.54-150.48a15 15 0 0 1 14.62-18.36h274.27a15 15 0 0 1 14.65 18.36l-34.6 150.48a15 15 0 0 1 -14.62 11.67zm-193.19-30h181.25l27.67-120.48h-236.6z'></path><path d='m222 450a57.48 57.48 0 1 1 57.48-57.48 57.54 57.54 0 0 1 -57.48 57.48zm0-84.95a27.48 27.48 0 1 0 27.48 27.47 27.5 27.5 0 0 0 -27.48-27.47z'></path><path d='m368.42 450a57.48 57.48 0 1 1 57.48-57.48 57.54 57.54 0 0 1 -57.48 57.48zm0-84.95a27.48 27.48 0 1 0 27.48 27.47 27.5 27.5 0 0 0 -27.48-27.47z'></path><path d='m158.08 165.49a15 15 0 0 1 -14.23-10.26l-25.71-77.23h-47.44a15 15 0 1 1 0-30h58.3a15 15 0 0 1 14.23 10.26l29.13 87.49a15 15 0 0 1 -14.23 19.74z'></path></svg>
        </button>
    </div>
</div>";
    }
} else {
    echo "<p>sorry, There is no Nots in the moment, come back latter</p>";
}
$conn->close();
?>
</div>
<!------ note modal popup to store in Student Explore Note table ------>
<div id="noteModal" class="modal">
<div class="modal-content" style="position: relative;">
    <!------ favorite icon ------->
<div style="position: absolute; top: 15px; left: 20px; z-index: 10;">
    <i id="noteFavoriteIcon" class="fa-regular fa-heart" 
       style="font-size: 22px; cursor: pointer; color: red;" 
       onclick="toggleNoteFavorite(currentNoteId)">
    </i>
</div>
    <span class="close" onclick="closeNoteModal()">&times;</span>
    <img id="modalImage" src="" alt="" style="width: 100%; max-height: 400px; object-fit: contain;">
    <h3 id="modalTitle"></h3>
    <p id="modalDesc"></p>
    <p><strong>Price:</strong> <span id="modalPrice"></span> ريال</p>
  </div>
</div>

<script>
// Toggle note favorite in database
let currentNoteId = null;
function toggleNoteFavorite(noteId) {
    fetch('toggle_favorite.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'type=note&id=' + noteId
    })
    .then(res => res.text())
    .then(handleNoteHeartResponse);
}

//lod the current note favorite state from DB
function loadNoteFavoriteState(noteId) {
    fetch('check_favorite.php?type=note&id=' + noteId)
    .then(res => res.text())
    .then(updateNoteHeartIcon);
}

//update the heart icon 
function updateNoteHeartIcon(isFav) {
    const icon = document.getElementById("noteFavoriteIcon");
    icon.classList.toggle("fa-solid", isFav === 'yes');
    icon.classList.toggle("fa-regular", isFav !== 'yes');
}

// deal with server response when the note is favorite
function handleNoteHeartResponse(status) {
    updateNoteHeartIcon(status === 'added' ? 'yes' : 'no');
}

//Java Script function for pop up modal display
function openNoteModal(noteId, title, desc, img, price) {
    currentNoteId = noteId; 
    document.getElementById("modalImage").src = img;
    document.getElementById("modalTitle").innerText = title;
    document.getElementById("modalDesc").innerText = desc;
    document.getElementById("modalPrice").innerText = price;
    document.getElementById("noteModal").style.display = "block";
    trackExplore(noteId);
 //Load heart icon status (liked or not )
    loadNoteFavoriteState(noteId); 
}

function closeNoteModal() {
    document.getElementById("noteModal").style.display = "none";
}

function trackExplore(noteId) {
    fetch(window.location.href, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'note_id=' + encodeURIComponent(noteId) + '&track_explore=1'
    });
}

//function for note adding in the Cart
function addToCartNote(noteId) {
    fetch('add_to_cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'note_id=' + encodeURIComponent(noteId)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            if (confirm(" Note added! Go to cart?")) {
                window.location.href = '../cart/cart.php';
            }
        } else if (data.status === 'exists') {
            alert("Note already in cart!");
        } else {
            alert(" Error: " + (data.message || "Something went wrong."));
        }
    })
    .catch(err => {
        console.error(err);
        alert(' Failed to add note to cart.');
    });
}
</script>
<br><br><br>
<?php include '../include/footer.html'; ?>
</body>
</html>
