<?php
session_start();
header('Content-Type: application/json');

//this part prevent not logged in student from using the cart without reloading the page.
if (!isset($_SESSION['student_id'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'You must be logged in to add to cart.']);
    exit();
}
//since the cart has two parts (notes and Book) with ech part has different relation, the book in one to many and 
// the note many to many, so when the student buys the book the book is removed from brows page, and when the Student byes note it styes in the brows page
$bookId = $_POST['book_id'] ?? null;
$noteId = $_POST['note_id'] ?? null;

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
if (!isset($_SESSION['cart_notes'])) $_SESSION['cart_notes'] = [];

//Adding the items to cart depending on the item(book or note )
if ($bookId) {
    if (!in_array($bookId, $_SESSION['cart'])) {
        $_SESSION['cart'][] = $bookId;
        echo json_encode(['status' => 'success', 'type' => 'book']);
    } else {
        echo json_encode(['status' => 'exists', 'type' => 'book']);
    }
} elseif ($noteId) {
    if (!in_array($noteId, $_SESSION['cart_notes'])) {
        $_SESSION['cart_notes'][] = $noteId;
        echo json_encode(['status' => 'success', 'type' => 'note']);
    } else {
        echo json_encode(['status' => 'exists', 'type' => 'note']);
    }
} else {
    //if there is no book or note id it will reject the adding process
    echo json_encode(['status' => 'error', 'message' => 'No ID provided']);
}
?>