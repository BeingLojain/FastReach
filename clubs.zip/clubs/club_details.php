<?php
    //session starting and prven not loged in student and redirct them to log in page
    session_start();

    include('../include/db_connect.php'); 

    if (!isset($_SESSION['student_id'])) {
        header("Location: ../home/login.php");
        exit();
    }

    include '../include/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Club Details</title>
    <link rel="stylesheet" href="styles.css" />
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-------------------------- ChatBoot دليلك and Back to top Button------------------------------>
<?php include '../include/shared_buttons.html';?>

<?php
if (isset($_GET['club_id'])) {
    $club_id = mysqli_real_escape_string($conn, $_GET['club_id']);
    $sql = "SELECT * FROM Club WHERE Club_ID = '$club_id'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $club = mysqli_fetch_assoc($result);
?>
    <section class="club-details-hero">
        <div class="club-details-container">
        <img src="<?php echo htmlspecialchars($club['club_image_URL']); ?>" alt="<?php echo htmlspecialchars($club['Club_name']); ?>" class="club-banner">
        <h1><?php echo htmlspecialchars($club['Club_name']); ?></h1>
        </div>
    </section>

    <section class="club-info">
        <div class="club-info-container">
            <div class="club-description">
                <h2>About the Club</h2>
                <p><?php echo nl2br(htmlspecialchars($club['description'])); ?></p>
            </div>

            <div class="club-details-grid">
                <div class="detail-card">
                    <i class="fas fa-users"></i>
                    <h3>Club Leader</h3>
                    <p><?php echo htmlspecialchars($club['club_leader']); ?></p>
                </div>
                <div class="detail-card">
                    <i class="fas fa-calendar"></i>
                    <h3>Meeting Schedule</h3>
                    <p><?php echo htmlspecialchars($club['meeting_schedule']); ?></p>
                </div>
                <div class="detail-card">
                    <i class="fas fa-envelope"></i>
                    <h3>Contact</h3>
                    <p><?php echo htmlspecialchars($club['contact']); ?></p>
                </div>
            </div>

            <div class="join-section">
                <h2>Join the Club</h2>
                <p>Interested in joining? Click below to register!</p>
                <a href="#" onclick="redirectWithMessage('<?php echo htmlspecialchars($club['Registration_link']); ?>')" class="register-btn">Register Now</a>
            </div>
        </div>
    </section>

    <section id="workshops" >
        <div class="club-workshops-container">
            <h2>Club Workshops</h2>
            <div class="cards-container">
                <?php
                $workshops_sql = "SELECT Workshop_ID, Workshop_name, Description, Registration_link, Workshop_image_URL FROM Workshop WHERE Club_ID = '$club_id'";
                $workshops_result = mysqli_query($conn, $workshops_sql);

                if ($workshops_result && mysqli_num_rows($workshops_result) > 0) {
                    while ($workshop = mysqli_fetch_assoc($workshops_result)) {
                        echo '<div class="card">';
                        echo '<img src="' . htmlspecialchars($workshop["Workshop_image_URL"]) . '" alt="' . htmlspecialchars($workshop["Workshop_name"]) . '">';
                        echo '<h3>' . htmlspecialchars($workshop["Workshop_name"]) . '</h3>';
                        echo '<p1>' . htmlspecialchars($workshop["Description"]) . '</p1>';
                        echo '<div class="card-buttons">';
                        echo '<a href="#" onclick="redirectWithMessage(\'' . htmlspecialchars($workshop["Registration_link"]) . '\')" class="register-link">Register for Workshop</a>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo "<p class='no-workshops'>No workshops available for this club at the moment.</p>";
                }
                ?>
            </div>
        </div>
    </section>
<?php
    } else {
        echo "<div class='error-message'>Club not found.</div>";
    }
} else {
    echo "<div class='error-message'>No club specified.</div>";
}
?>

<?php require '../include/footer.html'; ?>

<!-- JavaScript -->
 
<script>
    function redirectWithMessage(url) {
        const overlay = document.createElement('div');
        overlay.className = 'redirect-overlay';

        const messageBox = document.createElement('div');
        messageBox.className = 'redirect-message';
        messageBox.innerHTML = `
            <div>Redirecting you to the registration page 🔄 ...</div>
            <div class="redirect-spinner"></div>
        `;

        overlay.appendChild(messageBox);
        document.body.appendChild(overlay);

        setTimeout(() => {
            window.open(url, '_blank');
            overlay.remove();
        }, 2500);
    }
</script>

</body>
</html>
