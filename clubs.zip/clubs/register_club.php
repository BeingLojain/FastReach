<?php
session_start();
include('../include/db_connect.php');

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to register for clubs']);
    exit();
}

// Get POST data
$student_id = $_SESSION['student_id'];
$club_id = isset($_POST['club_id']) ? $_POST['club_id'] : null;

if (!$club_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid club ID']);
    exit();
}

// Check if student is already registered for this club
$check_sql = "SELECT * FROM student_enrolls_clubs WHERE Student_ID = ? AND Club_ID = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("ii", $student_id, $club_id);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows > 0) {
    // Student already registered, just return success
    echo json_encode(['success' => true, 'message' => 'Already registered for this club']);
    exit();
}

// Insert new registration
$insert_sql = "INSERT INTO student_enrolls_clubs (Student_ID, Club_ID) VALUES (?, ?)";
$insert_stmt = $conn->prepare($insert_sql);
$insert_stmt->bind_param("ii", $student_id, $club_id);

if ($insert_stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Successfully registered for the club']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error registering for the club']);
}

$check_stmt->close();
$insert_stmt->close();
$conn->close();
?> 