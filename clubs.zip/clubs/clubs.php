<?php
    //session starting and prven not loged in student and redirct them to log in page
    session_start();

    include('../include/db_connect.php'); 

    if (!isset($_SESSION['student_id'])) {
        header("Location: ../home/login.php");
        exit();
    }

    include '../include/header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Clubs & Workshops</title>
    <link rel="stylesheet" href="styles.css" />
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body> 

<!-------------------------- ChatBoot دليلك and Back to top Button------------------------------>
<?php include '../include/shared_buttons.html';?>

<!--------------------------------- S3:Background --------------------------------------->

<section class="S1_Background">
      <h1>Clubs & Workshops</h1>
      <p>
        This webpage allows you to explore and register for various clubs and workshops.
        You can easily join student organizations, participate in skill-building sessions, 
        and engage in activities that enhance your university experience.
      </p>


      <!------------- SubS 3:Buttons ref to club+workshop -------------------->

      <div class="buttons">
        <a href="#clubs" class="btn">Explore Clubs</a>
        <a href="#your-clubs" class="btn">My Clubs</a>
        <a href="#workshops" class="btn">Explore Workshops</a>
    </div>
</section>

<!----------------------------------- S4:Club-Section ------------------------------------>

<section id="clubs">
    <h2>Available Clubs</h2>
    <div class="cards-container">
        <?php
        $sql = "SELECT * FROM Club";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="card">';
                echo '<img src="' . htmlspecialchars($row["club_image_URL"]) . '" alt="' . htmlspecialchars($row["Club_name"]) . '">';
                echo '<h3>' . htmlspecialchars($row["Club_name"]) . '</h3>';
                echo '<p1>' . htmlspecialchars($row["description"]) . '</p1>';
                echo '<div class="card-buttons">';
                echo '<a href="club_details.php?club_id=' . htmlspecialchars($row["Club_ID"]) . '" class="details-link">View Details</a>';
                echo '<a href="#" onclick="registerForClub(' . htmlspecialchars($row["Club_ID"]) . ', \'' . htmlspecialchars($row["Registration_link"]) . '\')" class="register-link">Register Now</a>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "<p2>There are no Clubs available at the moment. Please check back later</p2>";
        }
        ?>
    </div>
</section>


<!-------------------------------- S5:Workshops-Section -------------------------------->

<section id="workshops">
    <h2>Available Workshops</h2>
    <div class="cards-container">
        <?php
        $sqlWorkshop = "SELECT w.Workshop_ID, w.Workshop_name, w.description, w.Registration_link, w.Workshop_image_URL, 
                        c.Club_name, c.club_image_URL as club_logo 
                        FROM Workshop w 
                        LEFT JOIN Club c ON w.Club_ID = c.Club_ID";
        $resultWorkshop = mysqli_query($conn, $sqlWorkshop); 

        if ($resultWorkshop && mysqli_num_rows($resultWorkshop) > 0) {
            while ($rowWorkshop = mysqli_fetch_assoc($resultWorkshop)) {
                echo '<div class="card">';
                echo '<img src="' . htmlspecialchars($rowWorkshop["Workshop_image_URL"]) . '" alt="' . htmlspecialchars($rowWorkshop["Workshop_name"]) . '">';
                echo '<div class="club-tag">';
                echo '<img src="../admin/' . htmlspecialchars($rowWorkshop["club_logo"]) . '" alt="Club Logo" class="club-logo">';
                echo '<span>By ' . htmlspecialchars($rowWorkshop["Club_name"]) . '</span>';
                echo '</div>';
                echo '<h3>' . htmlspecialchars($rowWorkshop["Workshop_name"]) . '</h3>';
                echo '<p1>' . htmlspecialchars($rowWorkshop["description"]) . '</p1>';
                echo '<div class="card-buttons">';
                echo '<a href="#" onclick="redirectWithMessage(\'' . htmlspecialchars($rowWorkshop["Registration_link"]) . '\')" class="register-link">Register for Workshop</a>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "<p2>There are no workshops available at the moment. Please check back later.</p2>";
        }
        ?>
    </div>
</section>

<!-------------------------------- S6:Your-Clubs-Section -------------------------------->

<section id="your-clubs">
    <h2>Clubs You're Interested In</h2>
    <div class="cards-container">
        <?php
        // Get clubs the student is registered for
        $student_id = $_SESSION['student_id'];
        $sql = "SELECT c.* FROM Club c 
                INNER JOIN student_enrolls_clubs sec ON c.Club_ID = sec.Club_ID 
                WHERE sec.Student_ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="card">';
                echo '<img src="' . htmlspecialchars($row["club_image_URL"]) . '" alt="' . htmlspecialchars($row["Club_name"]) . '">';
                echo '<h3>' . htmlspecialchars($row["Club_name"]) . '</h3>';
                echo '<p1>' . htmlspecialchars($row["description"]) . '</p1>';
                echo '<div class="card-buttons">';
                echo '<a href="club_details.php?club_id=' . htmlspecialchars($row["Club_ID"]) . '" class="details-link">View Details</a>';
                echo '<a href="#" onclick="redirectWithMessage(\'' . htmlspecialchars($row["Registration_link"]) . '\')" class="register-link">Visit Club Page</a>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "<p2>You haven't registered for any clubs yet. Explore the available clubs above!</p2>";
        }
        $stmt->close();
        ?>
    </div>
</section>

<!-- --------------------[footer] ---------------------------->
<?php include ('../include/footer.html') ;?>

<!-- JavaScript -->
<script>
    function redirectWithMessage(url) {
        const overlay = document.createElement('div');
        overlay.className = 'redirect-overlay';

        const messageBox = document.createElement('div');
        messageBox.className = 'redirect-message';
        messageBox.innerHTML = `
            <div>Redirecting you to the registration page 🔄 ...</div>
            <div class="redirect-spinner"></div>
        `;

        overlay.appendChild(messageBox);
        document.body.appendChild(overlay);

        setTimeout(() => {
            window.open(url, '_blank');
            overlay.remove();
        }, 2500);
    }

    function registerForClub(clubId, registrationLink) {
        // First save to database
        fetch('register_club.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'club_id=' + encodeURIComponent(clubId)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If successful, proceed with the redirect
                redirectWithMessage(registrationLink);
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error registering for club. Please try again.');
        });
    }
</script>
    
</body>
</html>
