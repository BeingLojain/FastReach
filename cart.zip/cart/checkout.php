<?php
//session start and require login if the student not logged in, it will be redircted to cart page and it will derict it to login

session_start();
include '../include/db_connect.php';

if (!isset($_SESSION['student_id'])) {
    $_SESSION['error_message'] = "You must be logged in to checkout.";
    header("Location: cart.php");
    exit();
}

$studentId = $_SESSION['student_id'];

$conn->begin_transaction();

try {
    // Set cookie for last purchase if we have item information
    if (isset($_SESSION['last_item'])) {
        $lastPurchaseData = array(
            'itemName' => $_SESSION['last_item']['name'],
            'itemType' => $_SESSION['last_item']['type'],
            'itemId' => $_SESSION['last_item']['id'],
            'timestamp' => time()
        );
        setcookie('lastPurchase', urlencode(json_encode($lastPurchaseData)), time() + (86400 * 7), '/'); // Cookie expires in 7 days
    }

    //Book purchasing (since the relation is one to many the book is deleted from brows and the student who bought it the id will be stored in the DB)
    if (!empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $bookId) {
            $stmt = $conn->prepare("SELECT bought_by FROM Book WHERE Book_ID = ?");
            $stmt->bind_param("i", $bookId);
            $stmt->execute();
            $stmt->bind_result($boughtBy);
            $stmt->fetch();
            $stmt->close();

            if ($boughtBy === null) {
                $stmt = $conn->prepare("UPDATE Book SET bought_by = ? WHERE Book_ID = ?");
                $stmt->bind_param("ii", $studentId, $bookId);
                $stmt->execute();
                $stmt->close();
            }
        }
    }

    //Note purchasing (since the relation is many to many the note is will not be deleted from brows but the student id and the note id will be stored in new table)
    if (!empty($_SESSION['cart_notes'])) {
        foreach ($_SESSION['cart_notes'] as $noteId) {
            $stmt = $conn->prepare("INSERT IGNORE INTO Student_Buy_Note (Note_ID, Student_ID) VALUES (?, ?)");
            $stmt->bind_param("ii", $noteId, $studentId);
            $stmt->execute();
            $stmt->close();
        }
    }

    //clear the cart and session data
    unset($_SESSION['cart']);
    unset($_SESSION['cart_notes']);
    unset($_SESSION['last_item']);

    $conn->commit();
    $conn->close();

    $_SESSION['success_message'] = "Checkout is successful, Thank you for your purchase in FastReach";
    header("Location: ../Books/BooksMainPage.php");
    exit();
} catch (Exception $e) {
    $conn->rollback();
    $conn->close();
    $_SESSION['error_message'] = "Something went wrong during checkout. Please try again";
    header("Location: cart.php");
    exit();
}
?>