<?php
//session start and require login if the student not logged in, it will be redircted to the home page
session_start(); 
if (!isset($_SESSION['student_id'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: ../home/login.php");
    exit();
}
//if there is an error message from a previous action (ex: checkout) it will be show at the top of the page
if (isset($_SESSION['error_message'])) {
    echo "<div class='error-box'>" . $_SESSION['error_message'] . "</div>";
    unset($_SESSION['error_message']);
}

include '../include/db_connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$student_id = $_SESSION['student_id'];
$cart = $_SESSION['cart'] ?? [];
$books = [];
$success = '';
$error = '';
// loading the book the student add into the cart (using array )
if (!empty($cart)) {
    $ids = implode(',', array_map('intval', $cart));
    $result = $conn->query("SELECT * FROM Book WHERE Book_ID IN ($ids)");
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
        // Store the last book info for the cookie
        $_SESSION['last_item'] = array(
            'name' => $row['Book_Title'],
            'type' => 'book',
            'id' => $row['Book_ID']
        );
    }
}

// Load notes in cart
$cart_notes = $_SESSION['cart_notes'] ?? [];
$notes = [];
if (!empty($cart_notes)) {
    $note_ids = implode(',', array_map('intval', $cart_notes));
    $result = $conn->query("SELECT * FROM note WHERE Note_ID IN ($note_ids)");
    while ($row = $result->fetch_assoc()) {
        $notes[] = $row;
        // Store the last note info for the cookie
        $_SESSION['last_item'] = array(
            'name' => $row['Note_Title'],
            'type' => 'note',
            'id' => $row['Note_ID']
        );
    }
}
//deal with books or not removing (and reload the page)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['remove_book_id'])) {
        $remove_id = $_POST['remove_book_id'];
        $_SESSION['cart'] = array_filter($_SESSION['cart'], fn($id) => $id != $remove_id);
        header("Location: cart.php");
        exit();
    }
    if (isset($_POST['remove_note_id'])) {
        $_SESSION['cart_notes'] = array_filter($_SESSION['cart_notes'], fn($id) => $id != $_POST['remove_note_id']);
        header("Location: cart.php");
        exit();
    }
    //deal with checkout (if it is card will check the info)
    if (isset($_POST['checkout'])) {
        $paymentMethod = $_POST['payment_method'] ?? 'card';
        $cardName = $_POST['card_name'] ?? '';
        $cardNumber = $_POST['card_number'] ?? '';
        $cvv = $_POST['cvv'] ?? '';

        if ($paymentMethod === 'card' && (empty($cardName) || empty($cardNumber) || empty($cvv))) {
            $error = "Please fill in all required payment fields";
        } else if (!$student_id) {
            $error = "You must be logged in to checkout.";
        } else {
            // Process the purchase and set cookie
            if (!empty($books)) {
                $stmt = $conn->prepare("UPDATE Book SET bought_by = ? WHERE Book_ID = ?");
                foreach ($books as $book) {
                    $stmt->bind_param("ii", $student_id, $book['Book_ID']);
                    $stmt->execute();
                }
            }
            $_SESSION['cart'] = [];
            $books = [];
            $success = "Checkout is successful, Thank you for your purchase in FastReach";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MY Cart</title>
  <style>
    * { box-sizing: border-box; }
    html, body { height: 100%; }
    body {
      background: linear-gradient(to bottom, rgba(107, 88, 97, 0.95), rgba(122, 99, 109, 0.73)), url('../images/MainBackground.jpeg') no-repeat center center/cover;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }
    .cart-wrapper {
  width: 100%;
  max-width: 800px;
  background: #fff;
  border-radius: 15px;
  padding: 20px;
  box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
  max-height: 90vh;               
  overflow-y: auto;               
  margin: auto;                   
}
    
    .back-button {
      font-size: 16px;
      text-decoration: none;
      color: #6B5A69;
      background-color: #6b5a6924;
      padding: 10px 16px;
      border-radius: 10px;
      transition: 0.3s;
    }

    .back-button:hover {
      background-color: #6b5a6970;
    }
    .cart-section {
      margin-bottom: 30px;
      max-height: 300px;
      overflow-y: auto;
    }
    .cart-item {
      display: flex;
      align-items: center;
      background: #f3e9e2;
      padding: 10px;
      border-radius: 10px;
      margin-bottom: 10px;
    }
    .cart-item img {
      width: 60px;
      height: 60px;
      object-fit: cover;
      border-radius: 5px;
      margin-right: 10px;
    }
    .product-content {
      flex-grow: 1;
    }
    .price { font-weight: bold; }
    .remove-btn {
      background: none;
      font-size: 20px;
      color: red;
      cursor: pointer;
      border: none;
    }
    .cart-summary {
      margin-top: 30px;
    }
    .cart-summary input,
    .cart-summary select {
      width: 100%;
      max-width: 100%;
      box-sizing: border-box;
      padding: 10px;
      margin-bottom: 12px;
      border-radius: 5px;
      border: 1px solid #aaa;
      font-size: 16px;
      height: 45px;
      font-family: inherit;
      background-color: #fff;
    }
    .cart-summary input[type='date'] {
      padding-right: 10px;
    }
    .checkout-btn {
      padding: 12px 20px;
      background-color: #9c7e8e;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      width: 100%;
      font-size: 16px;
    }
    .checkout-btn:hover { background:#b39ba6
      ; }
    .success, .error {
      font-weight: bold;
      text-align: center;
      margin-bottom: 15px;
    }
    .success { color: green; }
    .error { color: red; }
    .error-box {
    background-color: #ffe0e0;
    color: #b30000;
    padding: 12px;
    margin-bottom: 15px;
    border: 1px solid #b30000;
    border-radius: 8px;
}
  </style>
</head>
<body>
  <div class="cart-wrapper">
    <!-----return back to prevoise page using this link ----->
    <a href="javascript:history.back()" class="back-button">&#8592; Back</a>
    <form action="checkout.php" method="post">
     <!-----showing the items in the cart(books) ----->
      <div class="cart-section">
        <h2>Books in Cart</h2>
        <?php if (!empty($success)) echo '<p class="success">' . $success . '</p>'; ?>
        <?php if (!empty($error)) echo '<p class="error">' . $error . '</p>'; ?>
        <?php if (empty($books)): ?>
          <p>No books in cart.</p>
        <?php else: ?>
          <?php foreach ($books as $book): ?>
          <div class="cart-item" data-price="<?= $book['B_price'] ?>">
          <img src="../images/Bookicon-cart.png" alt="Book Icon">
            <div class="product-content">
              <p><strong><?= htmlspecialchars($book['Book_Title']) ?></strong></p>
              <p class="price"><span class="item-price"><?= number_format($book['B_price'], 2) ?></span> SAR</p>
            </div>
            <button type="submit" class="remove-btn" name="remove_book_id" value="<?= $book['Book_ID'] ?>" title="Remove">🗑️</button>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <?php
      $notes = [];
      if (!empty($_SESSION['cart_notes'])) {
          $note_ids = implode(',', array_map('intval', $_SESSION['cart_notes']));
          $result = $conn->query("SELECT * FROM Note WHERE Note_ID IN ($note_ids)");
          while ($row = $result->fetch_assoc()) {
              $notes[] = $row;
          }
      }
      ?>
  <!-----showing the items in the cart(notes) ----->
      <div class="cart-section">
        <h2>Notes in Cart</h2>
        <?php if (empty($notes)): ?>
          <p>No notes in cart.</p>
        <?php else: ?>
          <?php foreach ($notes as $note): ?>
          <div class="cart-item" data-price="<?= $note['N_price'] ?>">
          <img src="../images/Noteicon-cart.png" alt="Note Icon">
            <div class="product-content">
              <p><strong><?= htmlspecialchars($note['Note_Title']) ?></strong></p>
              <p class="price"><span class="item-price"><?= number_format($note['N_price'], 2) ?></span> SAR</p>
            </div>
            <button type="submit" class="remove-btn" name="remove_note_id" value="<?= $note['Note_ID'] ?>" title="Remove">🗑️</button>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div class="cart-summary">
        <h3>Payment Details</h3>
        <select id="payment-method" name="payment_method" onchange="toggleCardDetails()">
          <option value="card">Credit/Debit Card</option>
          <option value="cash">Cash</option>
        </select>
        <div id="card-details">
          <input type="text" name="card_number" placeholder="Card Number">
          <input type="text" name="card_name" placeholder="Cardholder Name">
          <input type="text" name="cvv" placeholder="CVC">
          <input type="date">
        </div>
        <p>Total: <strong><span id="total">0.00</span> SAR</strong></p>
        <button class="checkout-btn" type="submit" name="checkout">Check Out</button>
      </div>
    </form>
  </div>

  <script>

    //this function shows or hides the card fields based on selected payment method (card or cash)
    function toggleCardDetails() {
      const payment = document.getElementById("payment-method").value;
      document.getElementById("card-details").style.display = payment === "card" ? "block" : "none";
    }
//this function loop through all items in cart and then shows the price
    function updateTotal() {
      let total = 0;
      document.querySelectorAll(".cart-item").forEach(item => {
        const price = parseFloat(item.dataset.price);
        total += price;
      });
      document.getElementById("total").innerText = total.toFixed(2);
    }
    //make sure the total is calculated and every thing is shown in load
    document.addEventListener("DOMContentLoaded", () => {
      toggleCardDetails();
      updateTotal();
    });
  </script>
</body>
</html>